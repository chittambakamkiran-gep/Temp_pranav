# 🤖 Agentic AI JSON Mapper

An intelligent AI-powered application for mapping input JSON data to output JSON schemas using local Llama3.2, LangGraph workflows, and beautiful Streamlit UI.

## ✨ Features

- **🔄 Agentic AI Workflow**: Uses LangGraph nodes for intelligent data processing
- **🤖 Local LLM Integration**: Powered by Llama3.2 via Ollama
- **📊 Multi-format Support**: Handles JSON, CSV, Excel, and TXT files
- **🎯 Smart Schema Management**: Store and reuse output schemas with ChromaDB
- **🔍 Structured Output**: Pydantic models ensure consistent data validation
- **📈 LangSmith Observability**: Track and monitor AI workflow performance
- **🎨 Beautiful UI**: Modern Streamlit interface with interactive components
- **⚡ Real-time Processing**: Generate numpy-based mapping formulas
- **🔧 User Feedback Loop**: Iterative refinement of mappings

## 🏗️ Architecture

```
├── api/                    # FastAPI backend
├── ui/                     # Streamlit frontend
├── models/                 # Pydantic schemas
├── agents/                 # LLM client and LangGraph workflow
├── database/               # ChromaDB management
├── utils/                  # File processing utilities
├── config/                 # Application settings
└── examples/               # Sample data files
```

## 🚀 Quick Start

### Prerequisites

1. **Python 3.8+**
2. **Ollama** with Llama3.2 model
3. **Git**

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd super
```

2. **Install dependencies**
```bash
pip install -r requirements.txt
```

3. **Install and setup Ollama**
```bash
# Install Ollama (https://ollama.ai/)
curl -fsSL https://ollama.ai/install.sh | sh

# Pull Llama3.2 model
ollama pull llama3.2
```

4. **Set environment variables (optional)**
```bash
export LANGSMITH_API_KEY="your-langsmith-api-key"
```

### Running the Application

1. **Start the backend API**
```bash
python run_backend.py
```

2. **Start the Streamlit UI** (in a new terminal)
```bash
python run_ui.py
```

3. **Access the application**
- UI: http://localhost:8501
- API: http://localhost:8000
- API Docs: http://localhost:8000/docs

## 📝 Usage Guide

### 1. Upload Input Data
- Support formats: JSON, CSV, Excel (.xlsx/.xls), TXT
- Automatic schema detection and validation
- Preview of processed data

### 2. Configure Output Schema
- **Option A**: Select from existing schemas (stored in ChromaDB)
- **Option B**: Upload new JSON schema with optional field descriptions
- Assign nicknames for easy reuse

### 3. Generate AI Mappings
- AI analyzes input and output schemas
- Generates numpy-based Python formulas
- Provides explanations for mapping logic
- Supports user feedback for refinement

### 4. Execute Computation
- Run generated mappings on actual data
- View results with execution logs
- Download output as JSON
- Visualize results with interactive charts

## 🔧 Configuration

Edit `config/settings.py` to customize:

```python
class Settings:
    OLLAMA_MODEL: str = "llama3.2"
    LANGSMITH_API_KEY: Optional[str] = None
    CHROMA_DB_PATH: str = "./chroma_db"
    API_PORT: int = 8000
    UI_PORT: int = 8501
    MAX_FILE_SIZE_MB: int = 50
```

## 📊 Example Workflow

1. **Input Data** (employees.json):
```json
[
  {
    "name": "John Doe",
    "age": 28,
    "salary": 50000,
    "experience_years": 5,
    "performance_score": 85
  }
]
```

2. **Output Schema**:
```json
{
  "total_compensation": {"type": "float"},
  "seniority_level": {"type": "string"},
  "performance_category": {"type": "string"}
}
```

3. **AI-Generated Mappings**:
```python
total_compensation = salary * 1.2  # 20% bonus
seniority_level = np.where(experience_years > 10, "Senior", "Junior")
performance_category = np.where(performance_score > 80, "High", "Standard")
```

## 🛠️ API Endpoints

- `POST /upload-input` - Upload and process input files
- `POST /upload-output-schema` - Store new output schema
- `GET /output-schemas` - List all stored schemas
- `POST /generate-mapping` - Generate AI mappings
- `POST /execute-computation` - Execute mappings
- `GET /health` - Health check

## 🔍 Monitoring & Observability

- **LangSmith Integration**: Track LLM calls and performance
- **Structured Logging**: Comprehensive error tracking
- **Workflow Visualization**: LangGraph execution paths
- **Real-time Metrics**: Processing statistics

## 🎯 Supported Numpy Functions

The AI can generate mappings using:
- Mathematical: `np.sum`, `np.mean`, `np.std`, `np.var`
- Conditional: `np.where`, `np.select`
- Aggregation: `np.min`, `np.max`, `np.median`
- Transformation: `np.abs`, `np.sqrt`, `np.round`

## 🚨 Troubleshooting

### Common Issues

1. **Ollama Connection Error**
   - Ensure Ollama is running: `ollama serve`
   - Check if Llama3.2 is installed: `ollama list`

2. **ChromaDB Permission Issues**
   - Check write permissions for `./chroma_db` directory
   - Clear database: `rm -rf ./chroma_db`

3. **File Upload Errors**
   - Verify file format and size limits
   - Check file encoding (UTF-8 recommended)

### Performance Tips

- Use smaller datasets for faster processing
- Optimize numpy formulas for better execution
- Enable LangSmith for performance monitoring
- Cache frequently used output schemas

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🙏 Acknowledgments

- **Ollama**: Local LLM inference
- **LangChain/LangGraph**: AI workflow orchestration
- **ChromaDB**: Vector database for schema storage
- **Streamlit**: Beautiful web interface
- **FastAPI**: High-performance API framework 