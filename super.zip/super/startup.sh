#!/bin/bash

echo "🤖 Starting Agentic AI JSON Mapper..."
echo

echo "📦 Installing dependencies..."
pip install -r requirements.txt

echo
echo "🚀 Starting Backend API..."
python run_backend.py &
BACKEND_PID=$!

echo
echo "⏳ Waiting for backend to start..."
sleep 5

echo "🎨 Starting Streamlit UI..."
python run_ui.py &
UI_PID=$!

echo
echo "✅ Application started successfully!"
echo "Backend API: http://localhost:8000"
echo "Streamlit UI: http://localhost:8501"
echo "API Docs: http://localhost:8000/docs"
echo

echo "Press Ctrl+C to stop all services..."

trap "echo 'Stopping services...'; kill $BACKEND_PID $UI_PID; exit" INT

wait 