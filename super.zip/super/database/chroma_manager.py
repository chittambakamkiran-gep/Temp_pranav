import chromadb
from chromadb.config import Settings
import json
from typing import List, Dict, Optional
from models.schemas import OutputSchema, OutputSchemaField
import uuid
from datetime import datetime

class ChromaManager:
    def __init__(self, persist_directory: str = "./chroma_db"):
        self.client = chromadb.PersistentClient(
            path=persist_directory,
            settings=Settings(anonymized_telemetry=False)
        )
        self.collection = self.client.get_or_create_collection(
            name="output_schemas",
            metadata={"description": "Collection for storing output JSON schemas"}
        )

    def store_output_schema(self, schema: OutputSchema) -> str:
        schema_id = str(uuid.uuid4())
        schema.created_at = datetime.now().isoformat()
        
        schema_dict = {
            "nickname": schema.nickname,
            "schema": {k: v.dict() for k, v in schema.schema.items()},
            "created_at": schema.created_at
        }
        
        self.collection.add(
            documents=[json.dumps(schema_dict)],
            metadatas=[{"nickname": schema.nickname, "created_at": schema.created_at}],
            ids=[schema_id]
        )
        
        return schema_id

    def get_schema_by_nickname(self, nickname: str) -> Optional[OutputSchema]:
        results = self.collection.query(
            query_texts=[nickname],
            where={"nickname": nickname},
            n_results=1
        )
        
        if results['documents']:
            schema_data = json.loads(results['documents'][0])
            return OutputSchema(
                nickname=schema_data['nickname'],
                schema={
                    k: OutputSchemaField(**v) for k, v in schema_data['schema'].items()
                },
                created_at=schema_data.get('created_at')
            )
        return None

    def get_all_schema_nicknames(self) -> List[str]:
        results = self.collection.get()
        nicknames = []
        for metadata in results['metadatas']:
            nicknames.append(metadata['nickname'])
        return list(set(nicknames))

    def nickname_exists(self, nickname: str) -> bool:
        results = self.collection.query(
            query_texts=[nickname],
            where={"nickname": nickname},
            n_results=1
        )
        return len(results['documents']) > 0

    def delete_schema(self, nickname: str) -> bool:
        results = self.collection.query(
            query_texts=[nickname],
            where={"nickname": nickname},
            n_results=1
        )
        
        if results['ids']:
            self.collection.delete(ids=results['ids'][0])
            return True
        return False 