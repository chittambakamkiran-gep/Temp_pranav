import os
from typing import Optional

class Settings:
    OLLAMA_MODEL: str = "llama3.2"
    LANGSMITH_API_KEY: Optional[str] = os.getenv("LANGSMITH_API_KEY")
    CHROMA_DB_PATH: str = "./chroma_db"
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    UI_HOST: str = "0.0.0.0"
    UI_PORT: int = 8501
    
    MAX_FILE_SIZE_MB: int = 50
    ALLOWED_FILE_TYPES: list = ['.json', '.csv', '.xlsx', '.xls', '.txt']
    
    LOG_LEVEL: str = "INFO"
    ENABLE_CORS: bool = True
    
    NUMPY_FUNCTIONS: list = [
        'np.sum', 'np.mean', 'np.median', 'np.std', 'np.var',
        'np.min', 'np.max', 'np.abs', 'np.sqrt', 'np.round',
        'np.where', 'np.concatenate', 'np.array'
    ]

settings = Settings() 