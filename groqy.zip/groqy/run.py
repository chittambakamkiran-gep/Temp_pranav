import subprocess
import sys
import time
import threading
import os
from dotenv import load_dotenv

load_dotenv()

def run_fastapi():
    subprocess.run([sys.executable, "-m", "uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000", "--reload"])

def run_streamlit():
    time.sleep(3)
    subprocess.run([sys.executable, "-m", "streamlit", "run", "streamlit_app.py", "--server.port", "8501", "--server.address", "0.0.0.0"])

if __name__ == "__main__":
    if not os.getenv("GROQ_API_KEY"):
        print("❌ Error: GROQ_API_KEY not found in environment variables!")
        print("Please add your GROQ API key to the .env file")
        sys.exit(1)
    
    print("🚀 Starting JSON Mapping Agent...")
    print("📡 FastAPI will be available at: http://localhost:8000")
    print("🎨 Streamlit UI will be available at: http://localhost:8501")
    
    fastapi_thread = threading.Thread(target=run_fastapi, daemon=True)
    streamlit_thread = threading.Thread(target=run_streamlit, daemon=True)
    
    fastapi_thread.start()
    streamlit_thread.start()
    
    try:
        fastapi_thread.join()
        streamlit_thread.join()
    except KeyboardInterrupt:
        print("\n🛑 Shutting down...")
        sys.exit(0) 