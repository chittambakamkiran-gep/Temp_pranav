#!/usr/bin/env python3
import os
import sys
from pathlib import Path

def setup_environment():
    print("🎯 JSON Mapping Agent - Environment Setup")
    print("=" * 50)
    
    env_file = Path(".env")
    
    if env_file.exists():
        print("✅ .env file already exists!")
        response = input("Do you want to overwrite it? (y/n): ")
        if response.lower() != 'y':
            print("Setup cancelled.")
            return
    
    print("\n📝 Please provide the following API keys:")
    
    groq_key = input("Enter your GROQ API Key: ").strip()
    if not groq_key:
        print("❌ GROQ API Key is required!")
        sys.exit(1)
    
    langsmith_key = input("Enter your LangSmith API Key (optional, press Enter to skip): ").strip()
    
    env_content = f"""GROQ_API_KEY={groq_key}
LANGCHAIN_TRACING_V2=true
LANGCHAIN_ENDPOINT=https://api.smith.langchain.com
LANGCHAIN_API_KEY={langsmith_key if langsmith_key else 'your_langsmith_api_key_here'}
LANGCHAIN_PROJECT=json-mapping-agent
"""
    
    with open(".env", "w") as f:
        f.write(env_content)
    
    print("\n✅ Environment file created successfully!")
    print("\n🚀 To start the application, run:")
    print("   python run.py")
    print("\n📚 For more information, check the README.md file.")

if __name__ == "__main__":
    setup_environment() 