import streamlit as st
import requests
import json
import pandas as pd
import numpy as np
from typing import Dict, Any, List
from io import BytesIO
import plotly.express as px
import plotly.graph_objects as go
from streamlit_option_menu import option_menu
from streamlit_ace import st_ace
from io import BytesIO
import numpy as np

st.set_page_config(
    page_title="JSON Mapping Agent",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)

API_BASE_URL = "http://localhost:8000"

st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        text-align: center;
        margin-bottom: 2rem;
    }
    .section-header {
        color: #4a5568;
        border-bottom: 2px solid #e2e8f0;
        padding-bottom: 0.5rem;
        margin-bottom: 1rem;
    }
    .success-box {
        background: #f0fff4;
        border: 1px solid #68d391;
        border-radius: 0.5rem;
        padding: 1rem;
        margin: 1rem 0;
    }
    .warning-box {
        background: #fffbf0;
        border: 1px solid #f6ad55;
        border-radius: 0.5rem;
        padding: 1rem;
        margin: 1rem 0;
    }
    .error-box {
        background: #fff5f5;
        border: 1px solid #fc8181;
        border-radius: 0.5rem;
        padding: 1rem;
        margin: 1rem 0;
    }
</style>
""", unsafe_allow_html=True)

def main():
    st.markdown('<h1 class="main-header">🎯 JSON Mapping Agent</h1>', unsafe_allow_html=True)
    
    with st.sidebar:
        selected = option_menu(
            "Navigation",
            ["Input Data", "Output Schema", "Generate Mappings", "Results"],
            icons=['upload', 'gear', 'cpu', 'bar-chart'],
            menu_icon="cast",
            default_index=0,
            styles={
                "container": {"padding": "0!important", "background-color": "#fafafa"},
                "icon": {"color": "orange", "font-size": "25px"}, 
                "nav-link": {"font-size": "16px", "text-align": "left", "margin":"0px", "--hover-color": "#eee"},
                "nav-link-selected": {"background-color": "#02ab21"},
            }
        )
    
    if selected == "Input Data":
        input_data_section()
    elif selected == "Output Schema":
        output_schema_section()
    elif selected == "Generate Mappings":
        generate_mappings_section()
    elif selected == "Results":
        results_section()

def input_data_section():
    st.markdown('<h2 class="section-header">📁 Input Data Upload</h2>', unsafe_allow_html=True)
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### Upload your input file")
        uploaded_file = st.file_uploader(
            "Choose a file",
            type=['json', 'csv', 'xlsx', 'xls', 'txt'],
            help="Supported formats: JSON, CSV, Excel, TXT"
        )
        
        if uploaded_file is not None:
            if st.button("🚀 Process File", type="primary"):
                with st.spinner("Processing file..."):
                    try:
                        files = {"file": uploaded_file.getvalue()}
                        response = requests.post(f"{API_BASE_URL}/upload-input", files={"file": uploaded_file})
                        
                        if response.status_code == 200:
                            data = response.json()
                            st.session_state.input_schema = data["input_schema"]
                            st.session_state.input_data = data["data"]
                            st.session_state.filename = data["filename"]
                            
                            st.markdown('<div class="success-box">✅ File processed successfully!</div>', unsafe_allow_html=True)
                        else:
                            st.markdown(f'<div class="error-box">❌ Error: {response.text}</div>', unsafe_allow_html=True)
                    
                    except Exception as e:
                        st.markdown(f'<div class="error-box">❌ Error: {str(e)}</div>', unsafe_allow_html=True)
    
    with col2:
        st.markdown("### Supported File Types")
        st.info("""
        📄 **JSON**: Direct JSON objects or arrays  
        📊 **CSV**: Comma-separated values  
        📈 **Excel**: .xlsx or .xls files  
        📝 **TXT**: Text files (JSON, CSV, or plain text)
        """)
    
    if hasattr(st.session_state, 'input_schema'):
        st.markdown("### 📋 Input Schema Preview")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Field Types:**")
            schema_df = pd.DataFrame([
                {"Field": k, "Type": v} 
                for k, v in st.session_state.input_schema["fields"].items()
            ])
            st.dataframe(schema_df, use_container_width=True)
        
        with col2:
            st.markdown("**Sample Data:**")
            if isinstance(st.session_state.input_data, list) and st.session_state.input_data:
                sample_df = pd.DataFrame([st.session_state.input_data[0]])
                st.dataframe(sample_df, use_container_width=True)
            elif isinstance(st.session_state.input_data, dict):
                sample_df = pd.DataFrame([st.session_state.input_data])
                st.dataframe(sample_df, use_container_width=True)
        
        st.markdown("### 📊 Data Statistics")
        if isinstance(st.session_state.input_data, list):
            st.metric("Total Records", len(st.session_state.input_data))
            st.metric("Fields Count", len(st.session_state.input_schema["fields"]))

def output_schema_section():
    st.markdown('<h2 class="section-header">⚙️ Output Schema Management</h2>', unsafe_allow_html=True)
    
    tab1, tab2 = st.tabs(["📤 Upload New Schema", "📚 Existing Schemas"])
    
    with tab1:
        st.markdown("### Create New Output Schema")
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            nickname = st.text_input(
                "Schema Nickname",
                placeholder="Enter a unique nickname for this schema",
                help="This will be used to identify your schema later"
            )
            
            schema_input_method = st.radio(
                "Input Method",
                ["Upload JSON File", "Manual JSON Input"],
                horizontal=True
            )
            
            if schema_input_method == "Upload JSON File":
                schema_file = st.file_uploader(
                    "Upload Output Schema JSON",
                    type=['json'],
                    help="Upload a JSON file containing your output schema"
                )
                
                if schema_file is not None:
                    try:
                        schema_content = json.loads(schema_file.read())
                        st.json(schema_content)
                        st.session_state.temp_output_schema = schema_content
                    except json.JSONDecodeError:
                        st.error("Invalid JSON file")
            
            else:
                schema_json = st_ace(
                    value='{\n  "field1": "string",\n  "field2": "integer",\n  "field3": "float"\n}',
                    language='json',
                    theme='github',
                    height=200,
                    key="schema_editor"
                )
                
                if schema_json:
                    try:
                        schema_content = json.loads(schema_json)
                        st.session_state.temp_output_schema = schema_content
                    except json.JSONDecodeError:
                        st.error("Invalid JSON syntax")
        
        with col2:
            st.markdown("### Schema Guidelines")
            st.info("""
            **Expected Format:**
            ```json
            {
              "field_name": "data_type",
              "total_amount": "float",
              "customer_name": "string",
              "order_count": "integer"
            }
            ```
            
            **Supported Types:**
            - string
            - integer  
            - float
            - boolean
            - array
            - object
            """)
        
        if hasattr(st.session_state, 'temp_output_schema'):
            st.markdown("### Field Descriptions")
            st.markdown("Add descriptions for each field to help the AI understand the context:")
            
            descriptions = []
            for field_name in st.session_state.temp_output_schema.keys():
                col1, col2 = st.columns([1, 2])
                with col1:
                    st.text(field_name)
                with col2:
                    desc = st.text_input(
                        f"Description for {field_name}",
                        key=f"desc_{field_name}",
                        placeholder=f"Describe what {field_name} represents..."
                    )
                    if desc:
                        descriptions.append({
                            "field_name": field_name,
                            "description": desc,
                            "data_type": st.session_state.temp_output_schema[field_name]
                        })
            
            if nickname and descriptions and len(descriptions) == len(st.session_state.temp_output_schema):
                if st.button("💾 Save Output Schema", type="primary"):
                    with st.spinner("Saving schema..."):
                        try:
                            data = {
                                "nickname": nickname,
                                "schema_json": json.dumps(st.session_state.temp_output_schema),
                                "descriptions_json": json.dumps(descriptions)
                            }
                            
                            response = requests.post(f"{API_BASE_URL}/save-output-schema", data=data)
                            
                            if response.status_code == 200:
                                st.markdown('<div class="success-box">✅ Schema saved successfully!</div>', unsafe_allow_html=True)
                                st.rerun()
                            else:
                                st.markdown(f'<div class="error-box">❌ Error: {response.text}</div>', unsafe_allow_html=True)
                        
                        except Exception as e:
                            st.markdown(f'<div class="error-box">❌ Error: {str(e)}</div>', unsafe_allow_html=True)
    
    with tab2:
        st.markdown("### Available Schemas")
        
        try:
            response = requests.get(f"{API_BASE_URL}/list-output-schemas")
            if response.status_code == 200:
                schemas = response.json()["schemas"]
                
                if schemas:
                    for schema in schemas:
                        with st.expander(f"📋 {schema['nickname']} ({schema['field_count']} fields)"):
                            col1, col2 = st.columns([3, 1])
                            
                            with col1:
                                schema_response = requests.get(f"{API_BASE_URL}/get-output-schema/{schema['nickname']}")
                                if schema_response.status_code == 200:
                                    schema_data = schema_response.json()["schema"]
                                    st.json(schema_data)
                                    
                                    if st.button(f"Select {schema['nickname']}", key=f"select_{schema['nickname']}"):
                                        st.session_state.selected_output_schema = schema_data
                                        st.success(f"Selected schema: {schema['nickname']}")
                            
                            with col2:
                                if st.button(f"🗑️ Delete", key=f"delete_{schema['nickname']}", type="secondary"):
                                    delete_response = requests.delete(f"{API_BASE_URL}/delete-output-schema/{schema['nickname']}")
                                    if delete_response.status_code == 200:
                                        st.success("Schema deleted!")
                                        st.rerun()
                                    else:
                                        st.error("Failed to delete schema")
                else:
                    st.info("No schemas found. Create your first schema in the 'Upload New Schema' tab.")
            
        except Exception as e:
            st.error(f"Error loading schemas: {str(e)}")

def generate_mappings_section():
    st.markdown('<h2 class="section-header">🤖 Generate Mappings</h2>', unsafe_allow_html=True)
    
    if not hasattr(st.session_state, 'input_schema'):
        st.warning("⚠️ Please upload input data first!")
        return
    
    if not hasattr(st.session_state, 'selected_output_schema'):
        st.warning("⚠️ Please select an output schema first!")
        return
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("### 🎯 Generate Mappings")
        
        if st.button("🚀 Generate Mappings", type="primary", use_container_width=True):
            with st.spinner("🤖 AI is analyzing schemas and generating mappings..."):
                try:
                    data = {
                        "input_schema_json": json.dumps(st.session_state.input_schema),
                        "output_schema_json": json.dumps(st.session_state.selected_output_schema)
                    }
                    
                    response = requests.post(f"{API_BASE_URL}/generate-mappings", data=data)
                    
                    if response.status_code == 200:
                        result = response.json()
                        st.session_state.current_mappings = result["mappings"]
                        
                        st.markdown('<div class="success-box">✅ Mappings generated successfully!</div>', unsafe_allow_html=True)
                        
                        if result["warnings"]:
                            st.markdown('<div class="warning-box">⚠️ Warnings:</div>', unsafe_allow_html=True)
                            for warning in result["warnings"]:
                                st.warning(warning)
                    else:
                        st.markdown(f'<div class="error-box">❌ Error: {response.text}</div>', unsafe_allow_html=True)
                
                except Exception as e:
                    st.markdown(f'<div class="error-box">❌ Error: {str(e)}</div>', unsafe_allow_html=True)
    
    with col2:
        st.markdown("### ℹ️ Schema Info")
        st.info(f"""
        **Input Fields:** {len(st.session_state.input_schema['fields'])}  
        **Output Fields:** {len(st.session_state.selected_output_schema['fields'])}  
        **Schema:** {st.session_state.selected_output_schema['nickname']}
        """)
    
    # Display current mappings
    if hasattr(st.session_state, 'current_mappings'):
        st.markdown("### 📋 Generated Mappings")
        
        for i, mapping in enumerate(st.session_state.current_mappings):
            with st.expander(f"🎯 {mapping['output_field']}", expanded=True):
                col1, col2 = st.columns([2, 1])
                
                with col1:
                    st.code(mapping['formula'], language='python')
                    st.markdown(f"**Explanation:** {mapping['explanation']}")
                
                with col2:
                    st.markdown("**Input Fields Used:**")
                    for field in mapping['input_fields_used']:
                        st.badge(field, outline=True)
        
        # Modification section
        st.markdown("### ✏️ Modify Mappings")
        modification_request = st.text_area(
            "Describe your modifications:",
            placeholder="Example: Change the total_amount formula to multiply price by quantity instead of summing...",
            height=100
        )
        
        if modification_request and st.button("🔄 Apply Modifications"):
            with st.spinner("🤖 AI is modifying mappings..."):
                try:
                    data = {
                        "input_schema_json": json.dumps(st.session_state.input_schema),
                        "output_schema_json": json.dumps(st.session_state.selected_output_schema),
                        "current_mappings_json": json.dumps(st.session_state.current_mappings),
                        "modification_request": modification_request
                    }
                    
                    response = requests.post(f"{API_BASE_URL}/modify-mappings", data=data)
                    
                    if response.status_code == 200:
                        result = response.json()
                        st.session_state.current_mappings = result["mappings"]
                        st.success("✅ Mappings modified successfully!")
                        st.rerun()
                    else:
                        st.error(f"❌ Error: {response.text}")
                
                except Exception as e:
                    st.error(f"❌ Error: {str(e)}")
        
        # Accept mappings
        if st.button("✅ Accept Mappings", type="primary", use_container_width=True):
            st.session_state.accepted_mappings = st.session_state.current_mappings
            st.success("🎉 Mappings accepted! You can now compute results.")

def results_section():
    st.markdown('<h2 class="section-header">📊 Results & Computation</h2>', unsafe_allow_html=True)
    
    if not hasattr(st.session_state, 'accepted_mappings'):
        st.warning("⚠️ Please generate and accept mappings first!")
        return
    
    if not hasattr(st.session_state, 'input_data'):
        st.warning("⚠️ No input data available!")
        return
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        if st.button("🧮 Compute Output", type="primary", use_container_width=True):
            with st.spinner("🔬 Computing output using generated formulas..."):
                try:
                    data = {
                        "input_data_json": json.dumps(st.session_state.input_data),
                        "mappings_json": json.dumps(st.session_state.accepted_mappings)
                    }
                    
                    response = requests.post(f"{API_BASE_URL}/compute-output", data=data)
                    
                    if response.status_code == 200:
                        result = response.json()
                        
                        if result["success"]:
                            st.session_state.computed_results = result["result_data"]
                            st.markdown('<div class="success-box">✅ Computation completed successfully!</div>', unsafe_allow_html=True)
                        else:
                            st.markdown('<div class="error-box">❌ Computation failed:</div>', unsafe_allow_html=True)
                            for error in result["errors"]:
                                st.error(error)
                    else:
                        st.markdown(f'<div class="error-box">❌ Error: {response.text}</div>', unsafe_allow_html=True)
                
                except Exception as e:
                    st.markdown(f'<div class="error-box">❌ Error: {str(e)}</div>', unsafe_allow_html=True)
    
    with col2:
        if hasattr(st.session_state, 'accepted_mappings'):
            st.markdown("### 📋 Active Mappings")
            st.metric("Total Mappings", len(st.session_state.accepted_mappings))
    
    # Display results
    if hasattr(st.session_state, 'computed_results'):
        st.markdown("### 🎉 Computed Results")
        
        results_data = st.session_state.computed_results["records"]
        results_df = pd.DataFrame(results_data)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Records Processed", st.session_state.computed_results["count"])
        with col2:
            st.metric("Output Fields", len(results_df.columns))
        with col3:
            st.metric("Success Rate", "100%")
        
        # Display results table
        st.markdown("### 📋 Results Table")
        st.dataframe(results_df, use_container_width=True)
        
        # Download options
        st.markdown("### 💾 Download Results")
        col1, col2, col3 = st.columns(3)
        
        with col1:
            csv = results_df.to_csv(index=False)
            st.download_button(
                label="📄 Download CSV",
                data=csv,
                file_name="mapping_results.csv",
                mime="text/csv"
            )
        
        with col2:
            json_str = json.dumps(results_data, indent=2)
            st.download_button(
                label="📋 Download JSON",
                data=json_str,
                file_name="mapping_results.json",
                mime="application/json"
            )
        
        with col3:
            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine='openpyxl') as writer:
                results_df.to_excel(writer, index=False, sheet_name='Results')
            excel_data = excel_buffer.getvalue()
            
            st.download_button(
                label="📈 Download Excel",
                data=excel_data,
                file_name="mapping_results.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )
        
        # Visualizations
        if len(results_df.columns) > 1:
            st.markdown("### 📊 Data Visualization")
            
            numeric_columns = results_df.select_dtypes(include=[np.number]).columns.tolist()
            
            if len(numeric_columns) >= 2:
                col1, col2 = st.columns(2)
                
                with col1:
                    x_axis = st.selectbox("Select X-axis", numeric_columns)
                    y_axis = st.selectbox("Select Y-axis", [col for col in numeric_columns if col != x_axis])
                
                with col2:
                    chart_type = st.selectbox("Chart Type", ["Scatter", "Line", "Bar"])
                
                if x_axis and y_axis:
                    if chart_type == "Scatter":
                        fig = px.scatter(results_df, x=x_axis, y=y_axis, title=f"{y_axis} vs {x_axis}")
                    elif chart_type == "Line":
                        fig = px.line(results_df, x=x_axis, y=y_axis, title=f"{y_axis} vs {x_axis}")
                    else:
                        fig = px.bar(results_df, x=x_axis, y=y_axis, title=f"{y_axis} vs {x_axis}")
                    
                    st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    if 'GROQ_API_KEY' not in st.secrets:
        st.error("⚠️ Please add your GROQ_API_KEY to Streamlit secrets!")
        st.stop()
    
    main() 