# 🎯 JSON Mapping Agent

An intelligent agentic AI application that automatically generates mappings between input and output JSON schemas using GROQ AI, built with LangGraph for agent workflows and featuring a beautiful Streamlit UI.

## ✨ Features

- **🤖 AI-Powered Mapping**: Uses GROQ's LLM to intelligently generate NumPy-based mapping formulas
- **📁 Multi-Format Support**: Upload JSON, CSV, Excel, or TXT files as input
- **🗄️ Schema Management**: Store and reuse output schemas with ChromaDB
- **🔄 Interactive Modifications**: Modify generated mappings with natural language
- **⚡ Real-time Computation**: Execute mappings and get instant results
- **📊 Beautiful UI**: Modern, responsive Streamlit interface
- **📈 Data Visualization**: Built-in charts and visualizations
- **📥 Export Options**: Download results in CSV, JSON, or Excel formats
- **🔍 Observability**: LangSmith integration for monitoring and debugging

## 🏗️ Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Streamlit UI  │────│   FastAPI API   │────│   GROQ AI       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                              │
                              ├── ChromaDB (Schema Storage)
                              ├── LangGraph (Agent Workflow)
                              └── LangSmith (Observability)
```

## 🚀 Quick Start

### Prerequisites

- Python 3.8+
- GROQ API Key
- LangSmith API Key (optional, for observability)

### Installation

1. **Clone the repository:**
```bash
git clone <repository-url>
cd groqy
```

2. **Install dependencies:**
```bash
pip install -r requirements.txt
```

3. **Set up environment variables:**
```bash
cp .env.example .env
# Edit .env and add your API keys
```

4. **Run the application:**
```bash
python run.py
```

5. **Access the application:**
- 🎨 Streamlit UI: http://localhost:8501
- 📡 FastAPI Docs: http://localhost:8000/docs

## 🔧 Configuration

### Environment Variables

Create a `.env` file with the following variables:

```env
GROQ_API_KEY=your_groq_api_key_here
LANGCHAIN_TRACING_V2=true
LANGCHAIN_ENDPOINT=https://api.smith.langchain.com
LANGCHAIN_API_KEY=your_langsmith_api_key_here
LANGCHAIN_PROJECT=json-mapping-agent
```

## 📖 Usage Guide

### 1. Upload Input Data

- Navigate to the "Input Data" section
- Upload your file (JSON, CSV, Excel, or TXT)
- The system will automatically extract the schema

### 2. Manage Output Schemas

- Go to "Output Schema" section
- Either upload a new JSON schema or select from existing ones
- Add descriptions for each field to provide context to the AI

### 3. Generate Mappings

- In "Generate Mappings", click "Generate Mappings"
- The AI will create NumPy formulas to map input fields to output fields
- Review and modify mappings if needed using natural language

### 4. Compute Results

- Accept the mappings and go to "Results"
- Click "Compute Output" to execute the formulas
- Download results in your preferred format

## 🔄 Agent Workflow

The application uses LangGraph to orchestrate the following workflow:

```mermaid
graph TD
    A[Analyze Schemas] --> B[Generate Mappings]
    B --> C[Validate Mappings]
    D[Modify Mappings] --> C
    C --> E[Execute Formulas]
```

### Agent Nodes

1. **Analyze Schemas**: Compares input and output schemas
2. **Generate Mappings**: Creates NumPy formulas using GROQ AI
3. **Modify Mappings**: Updates mappings based on user feedback
4. **Validate Mappings**: Ensures formulas are valid and safe
5. **Execute Formulas**: Computes results using generated mappings

## 🎯 Example Mappings

The AI generates mappings like:

```python
# Direct mapping
output_field1 = input_field1

# Aggregation  
total_amount = np.sum(price * quantity)

# Calculation
profit_margin = (revenue - cost) / revenue * 100

# Conditional
status = "active" if last_login_days < 30 else "inactive"
```

## 📊 Data Types Support

### Input Formats
- **JSON**: Objects or arrays of objects
- **CSV**: Comma-separated values with headers
- **Excel**: .xlsx or .xls files
- **TXT**: Plain text, JSON, or delimited data

### Output Types
- string
- integer
- float
- boolean
- array
- object

## 🛡️ Security Features

- **Safe Execution**: Restricted Python evaluation environment
- **Input Validation**: Comprehensive validation using Pydantic
- **Error Handling**: Graceful error handling and user feedback
- **Schema Validation**: Ensures mappings only use available fields

## 🔍 Monitoring & Observability

The application integrates with LangSmith for:
- Request/response tracking
- Performance monitoring
- Error analysis
- Agent workflow visualization

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

If you encounter any issues:

1. Check the logs in the terminal
2. Verify your API keys are correctly set
3. Ensure all dependencies are installed
4. Check the FastAPI docs at http://localhost:8000/docs

## 🙏 Acknowledgments

- **GROQ** for the powerful AI capabilities
- **LangChain** for the agent framework
- **Streamlit** for the beautiful UI framework
- **ChromaDB** for vector storage
- **FastAPI** for the robust API framework 