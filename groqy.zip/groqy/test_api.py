#!/usr/bin/env python3
import requests
import json
import time
import sys

API_BASE_URL = "http://localhost:8000"

def test_api_endpoints():
    print("🧪 Testing JSON Mapping Agent API")
    print("=" * 40)
    
    # Test health check
    try:
        response = requests.get(f"{API_BASE_URL}/")
        if response.status_code == 200:
            print("✅ FastAPI server is running")
        else:
            print("❌ FastAPI server is not responding correctly")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to FastAPI server. Make sure it's running on port 8000")
        return False
    
    # Test list schemas endpoint
    try:
        response = requests.get(f"{API_BASE_URL}/list-output-schemas")
        if response.status_code == 200:
            print("✅ Schema listing endpoint works")
            schemas = response.json().get("schemas", [])
            print(f"   Found {len(schemas)} existing schemas")
        else:
            print("❌ Schema listing endpoint failed")
    except Exception as e:
        print(f"❌ Error testing schema endpoint: {e}")
    
    # Test file upload with sample data
    try:
        sample_data = {
            "customer_name": "Test Customer",
            "total_amount": 100.50,
            "quantity": 2
        }
        
        # Create a temporary JSON file in memory
        json_content = json.dumps([sample_data]).encode('utf-8')
        
        files = {"file": ("test.json", json_content, "application/json")}
        response = requests.post(f"{API_BASE_URL}/upload-input", files=files)
        
        if response.status_code == 200:
            print("✅ File upload endpoint works")
            result = response.json()
            if result.get("success"):
                print(f"   Successfully processed file with {len(result['input_schema']['fields'])} fields")
            else:
                print("❌ File processing failed")
        else:
            print(f"❌ File upload endpoint failed: {response.text}")
    except Exception as e:
        print(f"❌ Error testing file upload: {e}")
    
    print("\n🎉 API testing completed!")
    return True

if __name__ == "__main__":
    print("Make sure the FastAPI server is running (python run.py)")
    input("Press Enter to start testing...")
    test_api_endpoints() 