import numpy as np
import pandas as pd
from typing import Dict, Any, List
import ast
import operator
import math
from app.models.pydantic_models import MappingFormula, ComputationResult

class FormulaExecutor:
    def __init__(self):
        self.safe_functions = {
            'np': np,
            'sum': sum,
            'len': len,
            'abs': abs,
            'round': round,
            'min': min,
            'max': max,
            'math': math,
            'int': int,
            'float': float,
            'str': str,
            'bool': bool
        }
        
        self.safe_operators = {
            ast.Add: operator.add,
            ast.Sub: operator.sub,
            ast.Mult: operator.mul,
            ast.Div: operator.truediv,
            ast.FloorDiv: operator.floordiv,
            ast.Mod: operator.mod,
            ast.Pow: operator.pow,
            ast.USub: operator.neg,
            ast.UAdd: operator.pos,
        }
    
    def execute_mappings(
        self, 
        input_data: List[Dict[str, Any]], 
        mappings: List[MappingFormula]
    ) -> ComputationResult:
        try:
            if not input_data:
                return ComputationResult(
                    success=False,
                    result_data=None,
                    errors=["No input data provided"]
                )
            
            df = pd.DataFrame(input_data)
            results = []
            
            for record in input_data:
                output_record = {}
                record_errors = []
                
                for mapping in mappings:
                    try:
                        result_value = self._execute_formula(mapping.formula, record, df)
                        output_record[mapping.output_field] = result_value
                    except Exception as e:
                        record_errors.append(
                            f"Error computing {mapping.output_field}: {str(e)}"
                        )
                        output_record[mapping.output_field] = None
                
                if record_errors:
                    return ComputationResult(
                        success=False,
                        result_data=None,
                        errors=record_errors
                    )
                
                results.append(output_record)
            
            return ComputationResult(
                success=True,
                result_data={"records": results, "count": len(results)},
                errors=[]
            )
            
        except Exception as e:
            return ComputationResult(
                success=False,
                result_data=None,
                errors=[f"Execution error: {str(e)}"]
            )
    
    def _execute_formula(
        self, 
        formula: str, 
        record: Dict[str, Any], 
        df: pd.DataFrame
    ) -> Any:
        try:
            context = self.safe_functions.copy()
            context.update(record)
            
            context['data'] = df
            
            for col in df.columns:
                context[f"{col}_array"] = df[col].values
            
            result = eval(formula, {"__builtins__": None}, context)
            
            if isinstance(result, np.ndarray):
                if result.size == 1:
                    return result.item()
                else:
                    return result.tolist()
            elif isinstance(result, (np.integer, np.floating)):
                return result.item()
            elif pd.isna(result):
                return None
            else:
                return result
                
        except Exception as e:
            raise Exception(f"Formula execution failed: {str(e)}")
    
    def validate_formula(
        self, 
        formula: str, 
        available_fields: List[str]
    ) -> Dict[str, Any]:
        try:
            tree = ast.parse(formula, mode='eval')
            
            field_references = []
            self._extract_field_references(tree, field_references)
            
            invalid_fields = [
                field for field in field_references 
                if field not in available_fields and field not in self.safe_functions
            ]
            
            if invalid_fields:
                return {
                    "valid": False,
                    "errors": [f"Unknown fields: {invalid_fields}"],
                    "fields_used": field_references
                }
            
            return {
                "valid": True,
                "errors": [],
                "fields_used": [f for f in field_references if f in available_fields]
            }
            
        except SyntaxError as e:
            return {
                "valid": False,
                "errors": [f"Syntax error: {str(e)}"],
                "fields_used": []
            }
        except Exception as e:
            return {
                "valid": False,
                "errors": [f"Validation error: {str(e)}"],
                "fields_used": []
            }
    
    def _extract_field_references(self, node, field_refs):
        if isinstance(node, ast.Name):
            field_refs.append(node.id)
        elif isinstance(node, ast.Attribute):
            if isinstance(node.value, ast.Name):
                field_refs.append(f"{node.value.id}.{node.attr}")
        
        for child in ast.iter_child_nodes(node):
            self._extract_field_references(child, field_refs) 