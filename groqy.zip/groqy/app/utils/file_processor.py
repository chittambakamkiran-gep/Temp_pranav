import pandas as pd
import json
import numpy as np
from typing import Dict, Any, Tuple
from io import StringIO, BytesIO
from app.models.pydantic_models import InputSchema, FileType

class FileProcessor:
    @staticmethod
    def process_file(file_content: bytes, filename: str) -> Tuple[InputSchema, Dict[str, Any]]:
        file_extension = filename.split('.')[-1].lower()
        
        if file_extension == 'json':
            return FileProcessor._process_json(file_content)
        elif file_extension == 'csv':
            return FileProcessor._process_csv(file_content)
        elif file_extension in ['xlsx', 'xls']:
            return FileProcessor._process_excel(file_content)
        elif file_extension == 'txt':
            return FileProcessor._process_txt(file_content)
        else:
            raise ValueError(f"Unsupported file type: {file_extension}")
    
    @staticmethod
    def _process_json(file_content: bytes) -> Tuple[InputSchema, Dict[str, Any]]:
        try:
            data = json.loads(file_content.decode('utf-8'))
            
            if isinstance(data, list) and data:
                sample_record = data[0]
            elif isinstance(data, dict):
                sample_record = data
            else:
                raise ValueError("JSON must be an object or array of objects")
            
            fields = {}
            sample_data = {}
            
            for key, value in sample_record.items():
                if isinstance(value, (int, np.integer)):
                    fields[key] = "integer"
                elif isinstance(value, (float, np.floating)):
                    fields[key] = "float"
                elif isinstance(value, bool):
                    fields[key] = "boolean"
                elif isinstance(value, str):
                    fields[key] = "string"
                elif isinstance(value, list):
                    fields[key] = "array"
                elif isinstance(value, dict):
                    fields[key] = "object"
                else:
                    fields[key] = "string"
                
                sample_data[key] = value
            
            schema = InputSchema(fields=fields, sample_data=sample_data)
            return schema, data
            
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON format: {str(e)}")
    
    @staticmethod
    def _process_csv(file_content: bytes) -> Tuple[InputSchema, Dict[str, Any]]:
        try:
            content_str = file_content.decode('utf-8')
            df = pd.read_csv(StringIO(content_str))
            
            fields = {}
            sample_data = {}
            
            for col in df.columns:
                dtype = df[col].dtype
                if pd.api.types.is_integer_dtype(dtype):
                    fields[col] = "integer"
                elif pd.api.types.is_float_dtype(dtype):
                    fields[col] = "float"
                elif pd.api.types.is_bool_dtype(dtype):
                    fields[col] = "boolean"
                else:
                    fields[col] = "string"
                
                sample_data[col] = df[col].iloc[0] if not df[col].empty else None
            
            schema = InputSchema(fields=fields, sample_data=sample_data)
            data = df.to_dict('records')
            return schema, data
            
        except Exception as e:
            raise ValueError(f"Error processing CSV: {str(e)}")
    
    @staticmethod
    def _process_excel(file_content: bytes) -> Tuple[InputSchema, Dict[str, Any]]:
        try:
            df = pd.read_excel(BytesIO(file_content))
            
            fields = {}
            sample_data = {}
            
            for col in df.columns:
                dtype = df[col].dtype
                if pd.api.types.is_integer_dtype(dtype):
                    fields[col] = "integer"
                elif pd.api.types.is_float_dtype(dtype):
                    fields[col] = "float"
                elif pd.api.types.is_bool_dtype(dtype):
                    fields[col] = "boolean"
                else:
                    fields[col] = "string"
                
                sample_data[col] = df[col].iloc[0] if not df[col].empty else None
            
            schema = InputSchema(fields=fields, sample_data=sample_data)
            data = df.to_dict('records')
            return schema, data
            
        except Exception as e:
            raise ValueError(f"Error processing Excel: {str(e)}")
    
    @staticmethod
    def _process_txt(file_content: bytes) -> Tuple[InputSchema, Dict[str, Any]]:
        try:
            content_str = file_content.decode('utf-8')
            
            try:
                data = json.loads(content_str)
                return FileProcessor._process_json(file_content)
            except json.JSONDecodeError:
                pass
            
            lines = content_str.strip().split('\n')
            if len(lines) > 1 and (',' in lines[0] or '\t' in lines[0]):
                delimiter = ',' if ',' in lines[0] else '\t'
                df = pd.read_csv(StringIO(content_str), delimiter=delimiter)
                
                fields = {}
                sample_data = {}
                
                for col in df.columns:
                    fields[col] = "string"
                    sample_data[col] = df[col].iloc[0] if not df[col].empty else None
                
                schema = InputSchema(fields=fields, sample_data=sample_data)
                data = df.to_dict('records')
                return schema, data
            else:
                fields = {"text_content": "string"}
                sample_data = {"text_content": content_str[:100]}
                schema = InputSchema(fields=fields, sample_data=sample_data)
                return schema, {"text_content": content_str}
                
        except Exception as e:
            raise ValueError(f"Error processing text file: {str(e)}") 