from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
from enum import Enum

class FileType(str, Enum):
    JSON = "json"
    CSV = "csv"
    EXCEL = "excel"
    TXT = "txt"

class InputSchema(BaseModel):
    fields: Dict[str, str] = Field(description="Field names and their data types")
    sample_data: Dict[str, Any] = Field(description="Sample values for each field")

class OutputFieldDescription(BaseModel):
    field_name: str = Field(description="Name of the output field")
    description: str = Field(description="Description of what this field represents")
    data_type: str = Field(description="Expected data type of the field")

class OutputSchema(BaseModel):
    nickname: str = Field(description="Unique nickname for this output schema")
    fields: Dict[str, str] = Field(description="Field names and their data types")
    descriptions: List[OutputFieldDescription] = Field(description="Descriptions for each field")

class MappingFormula(BaseModel):
    output_field: str = Field(description="Name of the output field")
    formula: str = Field(description="NumPy formula for computing this field")
    input_fields_used: List[str] = Field(description="List of input fields used in the formula")
    explanation: str = Field(description="Human-readable explanation of the mapping")

class MappingResult(BaseModel):
    mappings: List[MappingFormula] = Field(description="List of field mappings")
    confidence_score: float = Field(description="Confidence score for the mappings (0-1)")
    warnings: List[str] = Field(default=[], description="Any warnings about the mappings")

class ModificationRequest(BaseModel):
    modification_text: str = Field(description="User's modification request")
    current_mappings: List[MappingFormula] = Field(description="Current mappings to modify")

class ComputationResult(BaseModel):
    success: bool = Field(description="Whether computation was successful")
    result_data: Optional[Dict[str, Any]] = Field(description="Computed output data")
    errors: List[str] = Field(default=[], description="Any errors during computation") 