from langgraph.graph import StateGraph, END
from langchain_groq import ChatGroq
from langchain.schema import SystemMessage, HumanMessage
from langchain.output_parsers import PydanticOutputParser
from typing import Dict, Any, List
import json
import os
from dotenv import load_dotenv

from app.models.pydantic_models import (
    InputSchema, OutputSchema, MappingResult, 
    ModificationRequest, MappingFormula
)

load_dotenv()

class MappingAgentState:
    def __init__(self):
        self.input_schema: InputSchema = None
        self.output_schema: OutputSchema = None
        self.current_mappings: List[MappingFormula] = []
        self.modification_request: str = ""
        self.final_mappings: List[MappingFormula] = []
        self.errors: List[str] = []

class MappingAgent:
    def __init__(self):
        self.llm = ChatGroq(
            groq_api_key=os.getenv("GROQ_API_KEY"),
            model_name="mixtral-8x7b-32768",
            temperature=0.1,
            max_tokens=4000
        )
        self.parser = PydanticOutputParser(pydantic_object=MappingResult)
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        workflow = StateGraph(dict)
        
        workflow.add_node("analyze_schemas", self._analyze_schemas_node)
        workflow.add_node("generate_mappings", self._generate_mappings_node)
        workflow.add_node("modify_mappings", self._modify_mappings_node)
        workflow.add_node("validate_mappings", self._validate_mappings_node)
        
        workflow.set_entry_point("analyze_schemas")
        
        workflow.add_edge("analyze_schemas", "generate_mappings")
        workflow.add_edge("generate_mappings", "validate_mappings")
        workflow.add_edge("modify_mappings", "validate_mappings")
        workflow.add_edge("validate_mappings", END)
        
        return workflow.compile()
    
    def _analyze_schemas_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        input_schema = state.get("input_schema")
        output_schema = state.get("output_schema")
        
        if not input_schema or not output_schema:
            state["errors"] = ["Missing input or output schema"]
            return state
        
        state["schema_analysis"] = {
            "input_fields": list(input_schema.fields.keys()),
            "output_fields": list(output_schema.fields.keys()),
            "input_types": input_schema.fields,
            "output_types": output_schema.fields
        }
        
        return state
    
    def _generate_mappings_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        input_schema = state["input_schema"]
        output_schema = state["output_schema"]
        
        system_prompt = """You are an expert data mapping specialist. Your task is to create NumPy-based Python formulas to map input fields to output fields.

IMPORTANT RULES:
1. Only use fields that exist in the input schema
2. Use only NumPy functions and basic Python operations
3. Each formula must be a single expression that can be evaluated
4. Use np.sum(), np.mean(), np.max(), np.min(), np.std() for aggregations
5. For direct mapping, just use the field name
6. For calculations, use arithmetic operations (+, -, *, /, **)
7. For string operations, use basic Python string methods
8. Always return valid Python code that can be executed

Examples:
- Direct mapping: input_field1
- Sum: np.sum(input_field2)  
- Average: np.mean(input_field3)
- Calculation: input_field1 * 1.1 + input_field2
- Conditional: input_field1 if input_field1 > 0 else 0

You must return a structured response with mappings for each output field."""

        field_descriptions = ""
        for desc in output_schema.descriptions:
            field_descriptions += f"- {desc.field_name}: {desc.description}\n"

        human_prompt = f"""
Input Schema Fields: {json.dumps(input_schema.fields, indent=2)}
Input Sample Data: {json.dumps(input_schema.sample_data, indent=2)}

Output Schema Fields: {json.dumps(output_schema.fields, indent=2)}
Output Field Descriptions:
{field_descriptions}

Create NumPy formulas to map each output field using available input fields. Consider the field descriptions and data types.

{self.parser.get_format_instructions()}
"""

        try:
            messages = [
                SystemMessage(content=system_prompt),
                HumanMessage(content=human_prompt)
            ]
            
            response = self.llm.invoke(messages)
            mapping_result = self.parser.parse(response.content)
            
            state["current_mappings"] = mapping_result.mappings
            state["confidence_score"] = mapping_result.confidence_score
            state["warnings"] = mapping_result.warnings
            
        except Exception as e:
            state["errors"] = [f"Error generating mappings: {str(e)}"]
        
        return state
    
    def _modify_mappings_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        modification_request = state.get("modification_request", "")
        if not modification_request:
            return state
            
        current_mappings = state.get("current_mappings", [])
        input_schema = state["input_schema"]
        
        system_prompt = """You are modifying existing field mappings based on user feedback. 
Update the mappings according to the user's request while maintaining the same structure and rules.

IMPORTANT RULES:
1. Only use fields that exist in the input schema
2. Use only NumPy functions and basic Python operations
3. Keep the same output field names unless explicitly asked to change them
4. Maintain valid Python syntax in all formulas"""

        human_prompt = f"""
Current Mappings:
{json.dumps([m.model_dump() for m in current_mappings], indent=2)}

Available Input Fields: {list(input_schema.fields.keys())}

User Modification Request: {modification_request}

Please update the mappings according to the user's request.

{self.parser.get_format_instructions()}
"""

        try:
            messages = [
                SystemMessage(content=system_prompt),
                HumanMessage(content=human_prompt)
            ]
            
            response = self.llm.invoke(messages)
            mapping_result = self.parser.parse(response.content)
            
            state["current_mappings"] = mapping_result.mappings
            state["confidence_score"] = mapping_result.confidence_score
            state["warnings"] = mapping_result.warnings
            
        except Exception as e:
            state["errors"] = [f"Error modifying mappings: {str(e)}"]
        
        return state
    
    def _validate_mappings_node(self, state: Dict[str, Any]) -> Dict[str, Any]:
        mappings = state.get("current_mappings", [])
        input_fields = set(state["input_schema"].fields.keys())
        
        validated_mappings = []
        validation_errors = []
        
        for mapping in mappings:
            try:
                used_fields = set(mapping.input_fields_used)
                if not used_fields.issubset(input_fields):
                    invalid_fields = used_fields - input_fields
                    validation_errors.append(
                        f"Mapping for {mapping.output_field} uses non-existent fields: {invalid_fields}"
                    )
                    continue
                
                validated_mappings.append(mapping)
                
            except Exception as e:
                validation_errors.append(
                    f"Error validating mapping for {mapping.output_field}: {str(e)}"
                )
        
        state["final_mappings"] = validated_mappings
        state["validation_errors"] = validation_errors
        
        return state
    
    async def generate_mappings(
        self, 
        input_schema: InputSchema, 
        output_schema: OutputSchema
    ) -> MappingResult:
        initial_state = {
            "input_schema": input_schema,
            "output_schema": output_schema,
            "errors": [],
            "modification_request": ""
        }
        
        result = await self.graph.ainvoke(initial_state)
        
        if result.get("errors"):
            return MappingResult(
                mappings=[],
                confidence_score=0.0,
                warnings=result["errors"]
            )
        
        return MappingResult(
            mappings=result.get("final_mappings", []),
            confidence_score=result.get("confidence_score", 0.0),
            warnings=result.get("warnings", []) + result.get("validation_errors", [])
        )
    
    async def modify_mappings(
        self,
        input_schema: InputSchema,
        output_schema: OutputSchema,
        current_mappings: List[MappingFormula],
        modification_request: str
    ) -> MappingResult:
        initial_state = {
            "input_schema": input_schema,
            "output_schema": output_schema,
            "current_mappings": current_mappings,
            "modification_request": modification_request,
            "errors": []
        }
        
        result = await self.graph.ainvoke(initial_state)
        
        if result.get("errors"):
            return MappingResult(
                mappings=current_mappings,
                confidence_score=0.0,
                warnings=result["errors"]
            )
        
        return MappingResult(
            mappings=result.get("final_mappings", []),
            confidence_score=result.get("confidence_score", 0.0),
            warnings=result.get("warnings", []) + result.get("validation_errors", [])
        ) 