import chromadb
from chromadb.config import Settings
import json
from typing import List, Optional, Dict, Any
from app.models.pydantic_models import OutputSchema
import uuid

class ChromaManager:
    def __init__(self, persist_directory: str = "./chroma_db"):
        self.client = chromadb.PersistentClient(
            path=persist_directory,
            settings=Settings(allow_reset=True)
        )
        self.collection = self.client.get_or_create_collection(
            name="output_schemas",
            metadata={"description": "Collection for storing output JSON schemas"}
        )
    
    def save_output_schema(self, schema: OutputSchema) -> str:
        schema_id = str(uuid.uuid4())
        schema_dict = schema.model_dump()
        
        self.collection.add(
            ids=[schema_id],
            documents=[json.dumps(schema_dict)],
            metadatas=[{
                "nickname": schema.nickname,
                "field_count": len(schema.fields),
                "schema_type": "output"
            }]
        )
        return schema_id
    
    def get_schema_by_nickname(self, nickname: str) -> Optional[OutputSchema]:
        results = self.collection.query(
            query_texts=[nickname],
            where={"nickname": nickname},
            n_results=1
        )
        
        if results['documents']:
            schema_dict = json.loads(results['documents'][0])
            return OutputSchema(**schema_dict)
        return None
    
    def list_all_schemas(self) -> List[Dict[str, str]]:
        results = self.collection.get()
        schemas = []
        
        for i, doc in enumerate(results['documents']):
            metadata = results['metadatas'][i]
            schemas.append({
                "nickname": metadata["nickname"],
                "field_count": metadata["field_count"],
                "id": results['ids'][i]
            })
        
        return schemas
    
    def delete_schema(self, nickname: str) -> bool:
        results = self.collection.query(
            query_texts=[nickname],
            where={"nickname": nickname},
            n_results=1
        )
        
        if results['ids']:
            self.collection.delete(ids=results['ids'])
            return True
        return False
    
    def schema_exists(self, nickname: str) -> bool:
        results = self.collection.query(
            query_texts=[nickname],
            where={"nickname": nickname},
            n_results=1
        )
        return len(results['documents']) > 0 