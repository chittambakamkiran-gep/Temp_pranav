from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
import uvicorn
import os
from typing import List, Optional
import json

from app.models.pydantic_models import (
    OutputSchema, MappingResult, ModificationRequest, 
    ComputationResult, OutputFieldDescription
)
from app.database.chroma_manager import ChromaManager
from app.utils.file_processor import FileProcessor
from app.agents.mapping_agent import MappingAgent
from app.compute.executor import FormulaExecutor

app = FastAPI(title="JSON Mapping Agent", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

chroma_manager = ChromaManager()
mapping_agent = MappingAgent()
formula_executor = FormulaExecutor()

app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", response_class=HTMLResponse)
async def read_root():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>JSON Mapping Agent</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <div style="text-align: center; margin-top: 50px;">
            <h1>JSON Mapping Agent</h1>
            <p>Visit <a href="/app">the Streamlit application</a> to use the mapping interface.</p>
        </div>
    </body>
    </html>
    """

@app.post("/upload-input")
async def upload_input_file(file: UploadFile = File(...)):
    try:
        content = await file.read()
        input_schema, data = FileProcessor.process_file(content, file.filename)
        
        return {
            "success": True,
            "input_schema": input_schema.model_dump(),
            "data": data,
            "filename": file.filename
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/save-output-schema")
async def save_output_schema(
    nickname: str = Form(...),
    schema_json: str = Form(...),
    descriptions_json: str = Form(...)
):
    try:
        if chroma_manager.schema_exists(nickname):
            raise HTTPException(status_code=400, detail="Nickname already exists")
        
        schema_dict = json.loads(schema_json)
        descriptions_list = json.loads(descriptions_json)
        
        descriptions = [OutputFieldDescription(**desc) for desc in descriptions_list]
        
        output_schema = OutputSchema(
            nickname=nickname,
            fields=schema_dict,
            descriptions=descriptions
        )
        
        schema_id = chroma_manager.save_output_schema(output_schema)
        
        return {
            "success": True,
            "schema_id": schema_id,
            "message": "Output schema saved successfully"
        }
    except json.JSONDecodeError:
        raise HTTPException(status_code=400, detail="Invalid JSON format")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/list-output-schemas")
async def list_output_schemas():
    try:
        schemas = chroma_manager.list_all_schemas()
        return {"success": True, "schemas": schemas}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/get-output-schema/{nickname}")
async def get_output_schema(nickname: str):
    try:
        schema = chroma_manager.get_schema_by_nickname(nickname)
        if not schema:
            raise HTTPException(status_code=404, detail="Schema not found")
        
        return {"success": True, "schema": schema.model_dump()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/generate-mappings")
async def generate_mappings(
    input_schema_json: str = Form(...),
    output_schema_json: str = Form(...)
):
    try:
        input_schema_dict = json.loads(input_schema_json)
        output_schema_dict = json.loads(output_schema_json)
        
        from app.models.pydantic_models import InputSchema
        input_schema = InputSchema(**input_schema_dict)
        output_schema = OutputSchema(**output_schema_dict)
        
        mapping_result = await mapping_agent.generate_mappings(input_schema, output_schema)
        
        return {
            "success": True,
            "mappings": [m.model_dump() for m in mapping_result.mappings],
            "confidence_score": mapping_result.confidence_score,
            "warnings": mapping_result.warnings
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/modify-mappings")
async def modify_mappings(
    input_schema_json: str = Form(...),
    output_schema_json: str = Form(...),
    current_mappings_json: str = Form(...),
    modification_request: str = Form(...)
):
    try:
        input_schema_dict = json.loads(input_schema_json)
        output_schema_dict = json.loads(output_schema_json)
        current_mappings_list = json.loads(current_mappings_json)
        
        from app.models.pydantic_models import InputSchema, MappingFormula
        input_schema = InputSchema(**input_schema_dict)
        output_schema = OutputSchema(**output_schema_dict)
        current_mappings = [MappingFormula(**m) for m in current_mappings_list]
        
        mapping_result = await mapping_agent.modify_mappings(
            input_schema, output_schema, current_mappings, modification_request
        )
        
        return {
            "success": True,
            "mappings": [m.model_dump() for m in mapping_result.mappings],
            "confidence_score": mapping_result.confidence_score,
            "warnings": mapping_result.warnings
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/compute-output")
async def compute_output(
    input_data_json: str = Form(...),
    mappings_json: str = Form(...)
):
    try:
        input_data = json.loads(input_data_json)
        mappings_list = json.loads(mappings_json)
        
        from app.models.pydantic_models import MappingFormula
        mappings = [MappingFormula(**m) for m in mappings_list]
        
        result = formula_executor.execute_mappings(input_data, mappings)
        
        return {
            "success": result.success,
            "result_data": result.result_data,
            "errors": result.errors
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/delete-output-schema/{nickname}")
async def delete_output_schema(nickname: str):
    try:
        success = chroma_manager.delete_schema(nickname)
        if not success:
            raise HTTPException(status_code=404, detail="Schema not found")
        
        return {"success": True, "message": "Schema deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000) 