import streamlit as st
import requests
import json
import pandas as pd
from typing import Dict, List, Optional
import plotly.express as px
import plotly.graph_objects as go
from streamlit_ace import st_ace
import base64

API_BASE_URL = "http://localhost:8000"

st.set_page_config(
    page_title="Agentic AI JSON Mapper",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)

def inject_custom_css():
    st.markdown("""
    <style>
    .main {
        padding-top: 2rem;
    }
    .stApp {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    .block-container {
        background: white;
        border-radius: 15px;
        padding: 2rem;
        margin: 1rem;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    }
    .upload-box {
        border: 3px dashed #667eea;
        border-radius: 10px;
        padding: 2rem;
        text-align: center;
        background: #f8f9ff;
        margin: 1rem 0;
    }
    .metric-card {
        background: linear-gradient(45deg, #667eea, #764ba2);
        color: white;
        padding: 1rem;
        border-radius: 10px;
        margin: 0.5rem 0;
        text-align: center;
    }
    .success-box {
        background: #d4edda;
        border: 1px solid #c3e6cb;
        border-radius: 5px;
        padding: 1rem;
        margin: 1rem 0;
    }
    .error-box {
        background: #f8d7da;
        border: 1px solid #f5c6cb;
        border-radius: 5px;
        padding: 1rem;
        margin: 1rem 0;
    }
    .mapping-card {
        background: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 1rem;
        margin: 0.5rem 0;
    }
    </style>
    """, unsafe_allow_html=True)

def display_hero_section():
    st.markdown("""
    <div style="text-align: center; padding: 2rem 0;">
        <h1 style="color: #667eea; font-size: 3rem; margin-bottom: 0.5rem;">🤖 Agentic AI JSON Mapper</h1>
        <p style="color: #666; font-size: 1.2rem;">Transform your data with intelligent AI-powered mapping</p>
    </div>
    """, unsafe_allow_html=True)

def display_file_upload_section():
    st.subheader("📁 Upload Input Data")
    
    with st.container():
        st.markdown('<div class="upload-box">', unsafe_allow_html=True)
        uploaded_file = st.file_uploader(
            "Choose your input file",
            type=['json', 'csv', 'xlsx', 'xls', 'txt'],
            help="Upload JSON, CSV, Excel, or TXT files"
        )
        st.markdown('</div>', unsafe_allow_html=True)
        
        if uploaded_file is not None:
            if st.button("Process Input File", type="primary"):
                with st.spinner("Processing file..."):
                    try:
                        files = {"file": (uploaded_file.name, uploaded_file.getvalue())}
                        response = requests.post(f"{API_BASE_URL}/upload-input", files=files)
                        
                        if response.status_code == 200:
                            result = response.json()
                            st.session_state.input_data = result["input_data"]
                            
                            st.markdown('<div class="success-box">', unsafe_allow_html=True)
                            st.success("✅ File processed successfully!")
                            st.markdown('</div>', unsafe_allow_html=True)
                            
                            display_input_schema(result["input_data"])
                        else:
                            st.error(f"❌ Error: {response.json().get('detail', 'Unknown error')}")
                    except Exception as e:
                        st.error(f"❌ Error processing file: {str(e)}")

def display_input_schema(input_data):
    st.subheader("📊 Input Schema")
    
    schema_df = pd.DataFrame([
        {"Field": field, "Type": field_type}
        for field, field_type in input_data["schema"].items()
    ])
    
    st.dataframe(schema_df, use_container_width=True)
    
    if isinstance(input_data["content"], list) and input_data["content"]:
        st.subheader("📋 Sample Data")
        sample_df = pd.DataFrame(input_data["content"][:5])
        st.dataframe(sample_df, use_container_width=True)

def display_output_schema_section():
    st.subheader("🎯 Output Schema Configuration")
    
    tab1, tab2 = st.tabs(["Select Existing Schema", "Upload New Schema"])
    
    with tab1:
        try:
            response = requests.get(f"{API_BASE_URL}/output-schemas")
            if response.status_code == 200:
                schemas = response.json()["schemas"]
                
                if schemas:
                    selected_schema = st.selectbox(
                        "Choose an existing output schema:",
                        [""] + schemas,
                        key="existing_schema"
                    )
                    
                    if selected_schema:
                        st.session_state.selected_output_schema = selected_schema
                        display_selected_schema(selected_schema)
                else:
                    st.info("No existing schemas found. Upload a new schema.")
            else:
                st.error("Error loading schemas")
        except Exception as e:
            st.error(f"Error: {str(e)}")
    
    with tab2:
        upload_new_schema()

def display_selected_schema(schema_nickname):
    try:
        response = requests.get(f"{API_BASE_URL}/output-schema/{schema_nickname}")
        if response.status_code == 200:
            schema_data = response.json()["schema"]
            
            st.subheader(f"Schema: {schema_nickname}")
            
            schema_fields = []
            for field_name, field_info in schema_data["schema"].items():
                schema_fields.append({
                    "Field": field_name,
                    "Type": field_info["field_type"],
                    "Description": field_info.get("description", "N/A")
                })
            
            schema_df = pd.DataFrame(schema_fields)
            st.dataframe(schema_df, use_container_width=True)
            
        else:
            st.error("Error loading schema details")
    except Exception as e:
        st.error(f"Error: {str(e)}")

def upload_new_schema():
    uploaded_schema = st.file_uploader(
        "Upload output schema (JSON)",
        type=['json'],
        key="new_schema_upload"
    )
    
    nickname = st.text_input("Schema Nickname:", key="schema_nickname")
    
    descriptions = st.text_area(
        "Field Descriptions (JSON format):",
        placeholder='{"field1": "Description for field1", "field2": "Description for field2"}',
        key="schema_descriptions"
    )
    
    if uploaded_schema and nickname:
        if st.button("Upload Schema", type="primary"):
            with st.spinner("Uploading schema..."):
                try:
                    files = {"file": (uploaded_schema.name, uploaded_schema.getvalue())}
                    data = {"nickname": nickname}
                    if descriptions.strip():
                        data["descriptions"] = descriptions
                    
                    response = requests.post(
                        f"{API_BASE_URL}/upload-output-schema",
                        files=files,
                        data=data
                    )
                    
                    if response.status_code == 200:
                        st.success("✅ Schema uploaded successfully!")
                        st.session_state.selected_output_schema = nickname
                        st.rerun()
                    else:
                        st.error(f"❌ Error: {response.json().get('detail', 'Unknown error')}")
                except Exception as e:
                    st.error(f"❌ Error uploading schema: {str(e)}")

def display_mapping_section():
    if not hasattr(st.session_state, 'input_data') or not hasattr(st.session_state, 'selected_output_schema'):
        st.info("Please upload input data and select/upload an output schema first.")
        return
    
    st.subheader("🔗 Generate Mapping")
    
    user_feedback = st.text_area(
        "Feedback or Instructions (optional):",
        placeholder="Provide any specific instructions for the mapping...",
        key="user_feedback"
    )
    
    if st.button("Generate Mapping", type="primary"):
        with st.spinner("Generating AI mapping..."):
            try:
                payload = {
                    "input_data": st.session_state.input_data,
                    "output_schema_nickname": st.session_state.selected_output_schema,
                    "user_feedback": user_feedback if user_feedback.strip() else None
                }
                
                response = requests.post(f"{API_BASE_URL}/generate-mapping", json=payload)
                
                if response.status_code == 200:
                    result = response.json()
                    st.session_state.mapping_result = result["mapping_result"]
                    display_mapping_result(result["mapping_result"])
                else:
                    st.error(f"❌ Error: {response.json().get('detail', 'Unknown error')}")
            except Exception as e:
                st.error(f"❌ Error generating mapping: {str(e)}")

def display_mapping_result(mapping_result):
    st.subheader("🎯 Generated Mappings")
    
    st.markdown('<div class="success-box">', unsafe_allow_html=True)
    st.success("✅ Mapping generated successfully!")
    st.markdown('</div>', unsafe_allow_html=True)
    
    st.markdown(f"**Explanation:** {mapping_result['explanation']}")
    
    for i, mapping in enumerate(mapping_result["mappings"]):
        st.markdown('<div class="mapping-card">', unsafe_allow_html=True)
        st.markdown(f"""
        **Output Field:** `{mapping['output_field']}`  
        **Formula:** `{mapping['formula']}`  
        **Input Fields Used:** {', '.join([f'`{field}`' for field in mapping['input_fields']])}  
        **Description:** {mapping.get('description', 'N/A')}
        """)
        st.markdown('</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("✅ Accept & Execute Mappings", type="primary"):
            st.session_state.mappings_accepted = True
            with st.spinner("Computing results..."):
                try:
                    payload = {
                        "input_data": st.session_state.input_data,
                        "output_schema_nickname": st.session_state.selected_output_schema,
                        "mappings": st.session_state.mapping_result["mappings"]
                    }
                    
                    response = requests.post(f"{API_BASE_URL}/execute-computation", json=payload)
                    
                    if response.status_code == 200:
                        result = response.json()
                        st.session_state.computation_result = result["computation_result"]
                        display_computation_result(result["computation_result"])
                    else:
                        st.error(f"❌ Error: {response.json().get('detail', 'Unknown error')}")
                except Exception as e:
                    st.error(f"❌ Error executing computation: {str(e)}")
    
    with col2:
        if st.button("🔄 Regenerate with Feedback"):
            st.session_state.show_feedback_form = True

def display_computation_section():
    if not hasattr(st.session_state, 'mappings_accepted') or not st.session_state.mappings_accepted:
        st.info("Please generate and accept mappings first.")
        return
    
    st.subheader("⚡ Execute Computation")
    
    if st.button("Execute Computation", type="primary"):
        with st.spinner("Computing results..."):
            try:
                payload = {
                    "input_data": st.session_state.input_data,
                    "output_schema_nickname": st.session_state.selected_output_schema,
                    "mappings": st.session_state.mapping_result["mappings"]
                }
                
                response = requests.post(f"{API_BASE_URL}/execute-computation", json=payload)
                
                if response.status_code == 200:
                    result = response.json()
                    display_computation_result(result["computation_result"])
                else:
                    st.error(f"❌ Error: {response.json().get('detail', 'Unknown error')}")
            except Exception as e:
                st.error(f"❌ Error executing computation: {str(e)}")

def display_computation_result(computation_result):
    st.subheader("📊 Computation Results")
    
    if computation_result["success"]:
        st.markdown('<div class="success-box">', unsafe_allow_html=True)
        st.success("✅ Computation completed successfully!")
        st.markdown('</div>', unsafe_allow_html=True)
        
        st.subheader("🎯 Output Data")
        output_df = pd.DataFrame([computation_result["output_data"]])
        st.dataframe(output_df, use_container_width=True)
        
        st.download_button(
            label="📥 Download JSON",
            data=json.dumps(computation_result["output_data"], indent=2),
            file_name="output_data.json",
            mime="application/json"
        )
        
        if st.button("📊 Visualize Results"):
            display_visualization(computation_result["output_data"])
    else:
        st.error("❌ Computation failed")
    
    with st.expander("View Execution Log"):
        for log_entry in computation_result["execution_log"]:
            if "Error" in log_entry:
                st.error(log_entry)
            else:
                st.info(log_entry)

def display_visualization(output_data):
    st.subheader("📈 Data Visualization")
    
    numeric_fields = []
    for key, value in output_data.items():
        try:
            float(value)
            numeric_fields.append(key)
        except:
            pass
    
    if numeric_fields:
        chart_type = st.selectbox("Select Chart Type:", ["Bar Chart", "Pie Chart", "Scatter Plot"])
        
        if chart_type == "Bar Chart":
            fig = px.bar(
                x=list(output_data.keys()),
                y=list(output_data.values()),
                title="Output Data Bar Chart"
            )
        elif chart_type == "Pie Chart" and len(numeric_fields) > 1:
            fig = px.pie(
                values=[output_data[field] for field in numeric_fields],
                names=numeric_fields,
                title="Output Data Distribution"
            )
        else:
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=list(range(len(output_data))),
                y=list(output_data.values()),
                mode='markers+lines',
                name='Output Values'
            ))
            fig.update_layout(title="Output Data Scatter Plot")
        
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No numeric data available for visualization")

def display_sidebar():
    with st.sidebar:
        st.markdown("### 🤖 AI Mapper Dashboard")
        
        if hasattr(st.session_state, 'input_data'):
            st.markdown('<div class="metric-card">', unsafe_allow_html=True)
            st.markdown("**Input Schema Fields**")
            st.markdown(f"**{len(st.session_state.input_data['schema'])}**")
            st.markdown('</div>', unsafe_allow_html=True)
        
        if hasattr(st.session_state, 'mapping_result'):
            st.markdown('<div class="metric-card">', unsafe_allow_html=True)
            st.markdown("**Generated Mappings**")
            st.markdown(f"**{len(st.session_state.mapping_result['mappings'])}**")
            st.markdown('</div>', unsafe_allow_html=True)
        
        st.markdown("---")
        st.markdown("### 🔧 Tools")
        
        if st.button("🔄 Reset Session"):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()
        
        if st.button("📋 View API Status"):
            try:
                response = requests.get(f"{API_BASE_URL}/health")
                if response.status_code == 200:
                    st.success("API is healthy")
                else:
                    st.error("API is down")
            except:
                st.error("Cannot connect to API")

def main():
    inject_custom_css()
    display_hero_section()
    display_sidebar()
    
    st.markdown("---")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        display_file_upload_section()
        
        if hasattr(st.session_state, 'input_data'):
            st.markdown("---")
            display_output_schema_section()
            
            if hasattr(st.session_state, 'selected_output_schema'):
                st.markdown("---")
                display_mapping_section()
                
                if hasattr(st.session_state, 'mapping_result'):
                    st.markdown("---")
                    display_computation_section()
                    
                    if hasattr(st.session_state, 'computation_result'):
                        st.markdown("---")
                        display_computation_result(st.session_state.computation_result)
    
    with col2:
        st.markdown("### 📊 Progress")
        
        progress_steps = [
            ("Upload Input", hasattr(st.session_state, 'input_data')),
            ("Select Schema", hasattr(st.session_state, 'selected_output_schema')),
            ("Generate Mapping", hasattr(st.session_state, 'mapping_result')),
            ("Execute", hasattr(st.session_state, 'mappings_accepted'))
        ]
        
        for step_name, completed in progress_steps:
            if completed:
                st.success(f"✅ {step_name}")
            else:
                st.info(f"⏳ {step_name}")

if __name__ == "__main__":
    main() 