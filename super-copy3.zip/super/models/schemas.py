from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any, Union
from enum import Enum

class FileType(str, Enum):
    JSON = "json"
    CSV = "csv"
    EXCEL = "excel"
    TXT = "txt"

class InputData(BaseModel):
    file_type: FileType
    content: Union[Dict, List[Dict], str]
    schema: Dict[str, str]

class OutputSchemaField(BaseModel):
    field_name: str
    field_type: str
    description: Optional[str] = None

class OutputSchema(BaseModel):
    nickname: str
    schema: Dict[str, OutputSchemaField]
    created_at: Optional[str] = None

class MappingFormula(BaseModel):
    output_field: str
    formula: str = Field(..., description="Python numpy formula for mapping")
    input_fields: List[str] = Field(..., description="Input fields used in the formula")
    description: Optional[str] = None

class MappingResult(BaseModel):
    mappings: List[MappingFormula] = Field(..., description="List of mapping formulas")
    explanation: str = Field(..., description="Overall explanation of the mapping logic")

class UserFeedback(BaseModel):
    modifications: str
    mapping_id: Optional[str] = None

class ComputationRequest(BaseModel):
    input_data: Dict[str, Any]
    mappings: List[MappingFormula]

class ComputationResult(BaseModel):
    output_data: Dict[str, Any]
    execution_log: List[str]
    success: bool
    error_message: Optional[str] = None 