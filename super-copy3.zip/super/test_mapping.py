#!/usr/bin/env python3
import pandas as pd
import numpy as np

# Test data (same as in your sample)
test_data = [
    {
        "name": "John Doe",
        "age": 28,
        "salary": 50000,
        "department": "Engineering",
        "experience_years": 5,
        "performance_score": 85,
        "location": "New York"
    },
    {
        "name": "Jane Smith",
        "age": 32,
        "salary": 65000,
        "department": "Marketing",
        "experience_years": 8,
        "performance_score": 92,
        "location": "California"
    },
    {
        "name": "Bob Johnson",
        "age": 45,
        "salary": 80000,
        "department": "Finance",
        "experience_years": 15,
        "performance_score": 78,
        "location": "Texas"
    }
]

# Convert to DataFrame
df = pd.DataFrame(test_data)
print("Input Data:")
print(df)
print("\n" + "="*50 + "\n")

# Create local variables (same as in computation engine)
local_vars = {}
for col in df.columns:
    local_vars[col] = df[col].values

local_vars['np'] = np

# Test some correct formulas
test_formulas = {
    "employee_id": "np.char.upper(np.char.replace(name.astype(str), ' ', '_'))",
    "total_compensation": "salary * 1.2",
    "seniority_level": "np.where(experience_years >= 10, 'Senior', 'Junior')",
    "performance_category": "np.where(performance_score >= 90, 'Excellent', np.where(performance_score >= 80, 'Good', 'Average'))",
    "avg_salary": "np.mean(salary)",
    "max_experience": "np.max(experience_years)"
}

print("Testing Formulas:")
print("-" * 30)

output_data = {}
for field, formula in test_formulas.items():
    try:
        safe_dict = {"__builtins__": {}, "np": np}
        safe_dict.update(local_vars)
        
        result = eval(formula, safe_dict)
        
        if hasattr(result, '__iter__') and not isinstance(result, str):
            if len(result) == 1:
                output_data[field] = result[0]
            else:
                output_data[field] = result.tolist()
        else:
            output_data[field] = result
            
        print(f"✅ {field}: {formula} = {output_data[field]}")
        
    except Exception as e:
        print(f"❌ {field}: {formula} = ERROR: {str(e)}")

print("\n" + "="*50 + "\n")
print("Final Output JSON:")
import json
print(json.dumps(output_data, indent=2)) 