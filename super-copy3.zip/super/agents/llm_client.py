import ollama
from typing import Dict, List, Optional
from models.schemas import MappingResult, MappingFormula
import json
from langsmith import Client
import os

class LLMClient:
    def __init__(self, model_name: str = "llama3.2", langsmith_api_key: Optional[str] = None):
        self.model_name = model_name
        self.client = ollama.Client()
        
        if langsmith_api_key:
            os.environ["LANGSMITH_API_KEY"] = langsmith_api_key
            self.langsmith_client = Client()
        else:
            self.langsmith_client = None

    def generate_mapping(
        self, 
        input_schema: Dict[str, str], 
        output_schema: Dict[str, Dict], 
        user_feedback: Optional[str] = None
    ) -> MappingResult:
        prompt = self._build_mapping_prompt(input_schema, output_schema, user_feedback)
        
        try:
            if self.langsmith_client:
                run_id = self.langsmith_client.create_run(
                    name="mapping_generation",
                    inputs={"input_schema": input_schema, "output_schema": output_schema},
                    run_type="llm"
                )
            
            response = self.client.generate(
                model=self.model_name,
                prompt=prompt,
                format="json",
                options={
                    "temperature": 0.1,
                    "top_p": 0.9,
                    "num_predict": 2048
                }
            )
            
            result_dict = json.loads(response['response'])
            
            mappings = []
            for mapping_data in result_dict.get('mappings', []):
                mapping = MappingFormula(
                    output_field=mapping_data['output_field'],
                    formula=mapping_data['formula'],
                    input_fields=mapping_data['input_fields'],
                    description=mapping_data.get('description')
                )
                mappings.append(mapping)
            
            result = MappingResult(
                mappings=mappings,
                explanation=result_dict.get('explanation', '')
            )
            
            if self.langsmith_client:
                self.langsmith_client.update_run(
                    run_id=run_id,
                    outputs={"result": result.dict()},
                    end_time=None
                )
            
            return result
            
        except Exception as e:
            if self.langsmith_client:
                self.langsmith_client.update_run(
                    run_id=run_id,
                    error=str(e),
                    end_time=None
                )
            raise Exception(f"Error generating mapping: {str(e)}")

    def _build_mapping_prompt(
        self, 
        input_schema: Dict[str, str], 
        output_schema: Dict[str, Dict], 
        user_feedback: Optional[str] = None
    ) -> str:
        prompt = f"""You are an expert data mapper. Your task is to create precise numpy-based Python formulas to map input fields to output fields.

INPUT SCHEMA:
{json.dumps(input_schema, indent=2)}

OUTPUT SCHEMA:
{json.dumps(output_schema, indent=2)}

IMPORTANT SYNTAX RULES:
1. Input fields are accessible directly by their column names (e.g., 'name', 'age', 'salary')
2. Do NOT use input_fields['fieldname'] - just use the field name directly
3. Each field contains an array of values from all rows
4. Use numpy functions for aggregations and transformations

REQUIREMENTS:
1. Create meaningful mappings based on field names and descriptions
2. Use appropriate numpy functions (np.sum, np.mean, np.max, np.min, np.std, np.where, etc.)
3. For string fields, use direct assignment or np.where for conditional logic
4. For numeric calculations, use appropriate numpy operations
5. Make logical sense - don't just return the same field

CORRECT EXAMPLES:
- total_compensation -> salary * 1.2  (add 20% bonus)
- avg_age -> np.mean(age)
- senior_status -> np.where(experience_years >= 10, "Senior", "Junior")
- max_salary -> np.max(salary)
- employee_id -> np.char.upper(np.char.replace(name.astype(str), " ", "_"))

AVOID:
- input_fields['name'] ❌
- Meaningless mappings like returning the same field
- Complex nested operations that don't make business sense

"""

        if user_feedback:
            prompt += f"""
USER FEEDBACK:
{user_feedback}

Please modify the mappings based on this feedback.
"""

        prompt += """
Return your response in the following JSON format:
{
    "mappings": [
        {
            "output_field": "field_name",
            "formula": "numpy_formula",
            "input_fields": ["list_of_input_fields_used"],
            "description": "brief_explanation"
        }
    ],
    "explanation": "overall_explanation_of_mapping_logic"
}

Ensure the JSON is valid and all formulas are executable Python numpy code."""

        return prompt 