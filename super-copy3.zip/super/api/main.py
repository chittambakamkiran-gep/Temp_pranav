from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from typing import Optional, List
import json
import os
from models.schemas import (
    InputData, OutputSchema, OutputSchemaField, MappingResult, 
    UserFeedback, ComputationResult, FileType
)
from pydantic import BaseModel
from utils.file_processor import FileProcessor
from database.chroma_manager import ChromaManager
from agents.llm_client import LLMClient
from agents.langgraph_workflow import MappingWorkflow, WorkflowState

app = FastAPI(title="Agentic AI JSON Mapper", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

chroma_manager = ChromaManager()
llm_client = LLMClient(
    model_name="llama3.2",
    langsmith_api_key=os.getenv("LANGSMITH_API_KEY")
)
workflow = MappingWorkflow(llm_client, chroma_manager)

@app.get("/")
async def root():
    return {"message": "Agentic AI JSON Mapper API"}

@app.post("/upload-input")
async def upload_input_file(file: UploadFile = File(...)):
    try:
        file_extension = file.filename.split('.')[-1].lower()
        
        if file_extension == 'json':
            file_type = FileType.JSON
        elif file_extension == 'csv':
            file_type = FileType.CSV
        elif file_extension in ['xlsx', 'xls']:
            file_type = FileType.EXCEL
        elif file_extension == 'txt':
            file_type = FileType.TXT
        else:
            raise HTTPException(status_code=400, detail="Unsupported file type")
        
        file_content = await file.read()
        input_data = FileProcessor.process_file(file_content, file_type, file.filename)
        
        return {
            "success": True,
            "input_data": input_data.dict(),
            "message": "File processed successfully"
        }
        
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/upload-output-schema")
async def upload_output_schema(
    file: UploadFile = File(...),
    nickname: str = Form(...),
    descriptions: Optional[str] = Form(None)
):
    try:
        if chroma_manager.nickname_exists(nickname):
            raise HTTPException(status_code=400, detail="Nickname already exists")
        
        file_content = await file.read()
        schema_data = json.loads(file_content.decode('utf-8'))
        
        descriptions_dict = {}
        if descriptions:
            try:
                descriptions_dict = json.loads(descriptions)
            except:
                pass
        
        schema_fields = {}
        for field_name, field_info in schema_data.items():
            if isinstance(field_info, dict):
                field_type = field_info.get('type', 'string')
                description = field_info.get('description') or descriptions_dict.get(field_name)
            else:
                field_type = str(type(field_info).__name__)
                description = descriptions_dict.get(field_name)
            
            schema_fields[field_name] = OutputSchemaField(
                field_name=field_name,
                field_type=field_type,
                description=description
            )
        
        output_schema = OutputSchema(
            nickname=nickname,
            schema=schema_fields
        )
        
        schema_id = chroma_manager.store_output_schema(output_schema)
        
        return {
            "success": True,
            "schema_id": schema_id,
            "nickname": nickname,
            "message": "Output schema stored successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/output-schemas")
async def get_output_schemas():
    try:
        nicknames = chroma_manager.get_all_schema_nicknames()
        return {
            "success": True,
            "schemas": nicknames
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/output-schema/{nickname}")
async def get_output_schema(nickname: str):
    try:
        schema = chroma_manager.get_schema_by_nickname(nickname)
        if not schema:
            raise HTTPException(status_code=404, detail="Schema not found")
        
        return {
            "success": True,
            "schema": schema.dict()
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class MappingRequest(BaseModel):
    input_data: InputData
    output_schema_nickname: str
    user_feedback: Optional[str] = None

@app.post("/generate-mapping")
async def generate_mapping(request: MappingRequest):
    try:
        output_schema = chroma_manager.get_schema_by_nickname(request.output_schema_nickname)
        if not output_schema:
            raise HTTPException(status_code=404, detail="Output schema not found")
        
        initial_state: WorkflowState = {
            "input_data": request.input_data,
            "output_schema": output_schema,
            "user_feedback": request.user_feedback,
            "mapping_result": None,
            "computation_result": None,
            "error": None,
            "step": "starting"
        }
        
        result = await workflow.run_workflow(initial_state)
        
        if result.get("error"):
            raise HTTPException(status_code=400, detail=result["error"])
        
        return {
            "success": True,
            "mapping_result": result["mapping_result"].dict() if result.get("mapping_result") else None,
            "step": result.get("step"),
            "message": "Mapping generated successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

class ComputationRequest(BaseModel):
    input_data: InputData
    output_schema_nickname: str
    mappings: List[dict]

@app.post("/execute-computation")
async def execute_computation(request: ComputationRequest):
    try:
        output_schema = chroma_manager.get_schema_by_nickname(request.output_schema_nickname)
        if not output_schema:
            raise HTTPException(status_code=404, detail="Output schema not found")
        
        mapping_objects = []
        for mapping_dict in request.mappings:
            from models.schemas import MappingFormula
            mapping_objects.append(MappingFormula(**mapping_dict))
        
        mapping_result = MappingResult(
            mappings=mapping_objects,
            explanation="User approved mappings"
        )
        
        initial_state: WorkflowState = {
            "input_data": request.input_data,
            "output_schema": output_schema,
            "mapping_result": mapping_result,
            "user_feedback": "execute",
            "computation_result": None,
            "error": None,
            "step": "ready_for_execution"
        }
        
        result = await workflow.run_workflow(initial_state)
        
        if result.get("error"):
            raise HTTPException(status_code=400, detail=result["error"])
        
        return {
            "success": True,
            "computation_result": result["computation_result"].dict() if result.get("computation_result") else None,
            "message": "Computation executed successfully"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/output-schema/{nickname}")
async def delete_output_schema(nickname: str):
    try:
        success = chroma_manager.delete_schema(nickname)
        if not success:
            raise HTTPException(status_code=404, detail="Schema not found")
        
        return {
            "success": True,
            "message": f"Schema '{nickname}' deleted successfully"
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    return {"status": "healthy", "message": "API is running"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 