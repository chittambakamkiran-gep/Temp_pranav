#!/usr/bin/env python3

import sys
import os
import json
from pathlib import Path

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_file_processing():
    print("🧪 Testing File Processing...")
    
    try:
        from app.utils.file_processor import FileProcessor
        
        with open('examples/sample_input.json', 'rb') as f:
            content = f.read()
        
        processor = FileProcessor()
        result = processor.process_file(content, 'sample_input.json', 'json')
        
        print("✅ JSON processing successful")
        print(f"   - Schema extracted with {len(result.schema.get('properties', {}))} fields")
        print(f"   - Data contains {len(result.data)} keys")
        
        return True
    except Exception as e:
        print(f"❌ File processing failed: {e}")
        return False

def test_chroma_manager():
    print("\n🧪 Testing ChromaDB Manager...")
    
    try:
        from app.database.chroma_manager import ChromaManager
        from app.models.schemas import OutputSchema
        
        manager = ChromaManager()
        
        test_schema = OutputSchema(
            nickname="test_schema",
            schema_data={"type": "object", "properties": {"name": {"type": "string"}}},
            field_descriptions={"name": "Test field description"}
        )
        
        schema_id = manager.store_output_schema(test_schema)
        print("✅ Schema storage successful")
        print(f"   - Schema ID: {schema_id}")
        
        retrieved = manager.get_schema_by_nickname("test_schema")
        if retrieved:
            print("✅ Schema retrieval successful")
            print(f"   - Retrieved schema: {retrieved.nickname}")
        
        manager.delete_schema("test_schema")
        print("✅ Schema deletion successful")
        
        return True
    except Exception as e:
        print(f"❌ ChromaDB test failed: {e}")
        return False

def test_pydantic_models():
    print("\n🧪 Testing Pydantic Models...")
    
    try:
        from app.models.schemas import MappingRequest, FieldMapping, MappingResponse
        
        mapping = FieldMapping(
            output_field="test_field",
            formula="input_field",
            input_fields=["input_field"],
            description="Test mapping"
        )
        
        response = MappingResponse(
            mappings=[mapping],
            explanation="Test explanation"
        )
        
        print("✅ Pydantic models work correctly")
        print(f"   - Created mapping for: {mapping.output_field}")
        
        return True
    except Exception as e:
        print(f"❌ Pydantic models test failed: {e}")
        return False

def test_formula_execution():
    print("\n🧪 Testing Formula Execution...")
    
    try:
        from app.compute.executor import FormulaExecutor
        from app.models.schemas import FieldMapping
        
        executor = FormulaExecutor()
        
        input_data = {
            "field1": 10,
            "field2": 20,
            "field3": 30
        }
        
        mappings = [
            FieldMapping(
                output_field="sum_result",
                formula="np.sum([field1, field2])",
                input_fields=["field1", "field2"]
            ),
            FieldMapping(
                output_field="direct_mapping",
                formula="field3",
                input_fields=["field3"]
            )
        ]
        
        result = executor.execute_mappings(input_data, mappings)
        
        print("✅ Formula execution successful")
        print(f"   - Sum result: {result.get('sum_result')}")
        print(f"   - Direct mapping: {result.get('direct_mapping')}")
        
        return True
    except Exception as e:
        print(f"❌ Formula execution test failed: {e}")
        return False

def check_dependencies():
    print("🧪 Checking Dependencies...")
    
    required_packages = [
        'streamlit', 'langchain', 'langchain_groq', 'langgraph',
        'chromadb', 'pydantic', 'pandas', 'numpy', 'openpyxl'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"   ✅ {package}")
        except ImportError:
            print(f"   ❌ {package} - MISSING")
            missing_packages.append(package)
    
    if missing_packages:
        print(f"\n❌ Missing packages: {', '.join(missing_packages)}")
        print("Run: pip install -r requirements.txt")
        return False
    else:
        print("\n✅ All dependencies installed")
        return True

def check_environment():
    print("\n🧪 Checking Environment Variables...")
    
    import config
    
    if config.GROQ_API_KEY and config.GROQ_API_KEY != "your_groq_api_key_here":
        print("   ✅ GROQ_API_KEY is set")
    else:
        print("   ❌ GROQ_API_KEY not found or not configured")
        print("   Please set your GROQ API key in .env file")
        return False
    
    print("   ✅ Environment configuration looks good")
    return True

def main():
    print("🎯 GroqY JSON Mapper - Application Test Suite")
    print("=" * 50)
    
    tests = [
        ("Dependencies", check_dependencies),
        ("Environment", check_environment),
        ("Pydantic Models", test_pydantic_models),
        ("File Processing", test_file_processing),
        ("ChromaDB Manager", test_chroma_manager),
        ("Formula Execution", test_formula_execution)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
        except Exception as e:
            print(f"❌ {test_name} test crashed: {e}")
    
    print("\n" + "=" * 50)
    print(f"🎯 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Your application is ready to run.")
        print("Start the app with: streamlit run streamlit_app.py")
    else:
        print("⚠️  Some tests failed. Please check the issues above.")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1) 