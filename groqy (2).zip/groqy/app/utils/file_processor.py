import json
import pandas as pd
import numpy as np
from typing import Dict, Any, Tuple, List
import io
from jsonschema import validate, ValidationError
from app.models.schemas import InputData

class FileProcessor:
    
    @staticmethod
    def extract_schema_from_data(data: Dict[str, Any]) -> Dict[str, Any]:
        schema = {"type": "object", "properties": {}}
        
        for key, value in data.items():
            if isinstance(value, str):
                schema["properties"][key] = {"type": "string"}
            elif isinstance(value, int):
                schema["properties"][key] = {"type": "integer"}
            elif isinstance(value, float):
                schema["properties"][key] = {"type": "number"}
            elif isinstance(value, bool):
                schema["properties"][key] = {"type": "boolean"}
            elif isinstance(value, list):
                if value and isinstance(value[0], dict):
                    schema["properties"][key] = {
                        "type": "array",
                        "items": FileProcessor.extract_schema_from_data(value[0])
                    }
                else:
                    schema["properties"][key] = {"type": "array"}
            elif isinstance(value, dict):
                schema["properties"][key] = FileProcessor.extract_schema_from_data(value)
            else:
                schema["properties"][key] = {"type": "string"}
        
        return schema
    
    @staticmethod
    def process_json_file(file_content: bytes, file_name: str) -> InputData:
        try:
            content = file_content.decode('utf-8')
            data = json.loads(content)
            
            if isinstance(data, list) and data:
                data = data[0]
            
            schema = FileProcessor.extract_schema_from_data(data)
            
            return InputData(
                file_name=file_name,
                file_type="json",
                data=data,
                schema=schema
            )
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON format: {str(e)}")
        except Exception as e:
            raise ValueError(f"Error processing JSON file: {str(e)}")
    
    @staticmethod
    def process_csv_file(file_content: bytes, file_name: str) -> InputData:
        try:
            content = io.StringIO(file_content.decode('utf-8'))
            df = pd.read_csv(content)
            
            if df.empty:
                raise ValueError("CSV file is empty")
            
            data = df.iloc[0].to_dict()
            
            for key, value in data.items():
                if pd.isna(value):
                    data[key] = None
                elif isinstance(value, np.integer):
                    data[key] = int(value)
                elif isinstance(value, np.floating):
                    data[key] = float(value)
            
            schema = FileProcessor.extract_schema_from_data(data)
            
            return InputData(
                file_name=file_name,
                file_type="csv",
                data=data,
                schema=schema
            )
        except Exception as e:
            raise ValueError(f"Error processing CSV file: {str(e)}")
    
    @staticmethod
    def process_excel_file(file_content: bytes, file_name: str) -> InputData:
        try:
            df = pd.read_excel(io.BytesIO(file_content))
            
            if df.empty:
                raise ValueError("Excel file is empty")
            
            data = df.iloc[0].to_dict()
            
            for key, value in data.items():
                if pd.isna(value):
                    data[key] = None
                elif isinstance(value, np.integer):
                    data[key] = int(value)
                elif isinstance(value, np.floating):
                    data[key] = float(value)
            
            schema = FileProcessor.extract_schema_from_data(data)
            
            return InputData(
                file_name=file_name,
                file_type="excel",
                data=data,
                schema=schema
            )
        except Exception as e:
            raise ValueError(f"Error processing Excel file: {str(e)}")
    
    @staticmethod
    def process_txt_file(file_content: bytes, file_name: str) -> InputData:
        try:
            content = file_content.decode('utf-8').strip()
            
            try:
                data = json.loads(content)
                if isinstance(data, list) and data:
                    data = data[0]
            except json.JSONDecodeError:
                lines = content.split('\n')
                data = {}
                for i, line in enumerate(lines):
                    if ':' in line:
                        key, value = line.split(':', 1)
                        key = key.strip()
                        value = value.strip()
                        try:
                            data[key] = json.loads(value)
                        except:
                            data[key] = value
                    else:
                        data[f"field_{i+1}"] = line.strip()
            
            schema = FileProcessor.extract_schema_from_data(data)
            
            return InputData(
                file_name=file_name,
                file_type="txt",
                data=data,
                schema=schema
            )
        except Exception as e:
            raise ValueError(f"Error processing TXT file: {str(e)}")
    
    @staticmethod
    def process_file(file_content: bytes, file_name: str, file_type: str) -> InputData:
        processors = {
            'json': FileProcessor.process_json_file,
            'csv': FileProcessor.process_csv_file,
            'xlsx': FileProcessor.process_excel_file,
            'xls': FileProcessor.process_excel_file,
            'txt': FileProcessor.process_txt_file
        }
        
        if file_type not in processors:
            raise ValueError(f"Unsupported file type: {file_type}")
        
        return processors[file_type](file_content, file_name) 