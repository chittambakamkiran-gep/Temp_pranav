import chromadb
from chromadb.config import Settings
import json
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from app.models.schemas import OutputSchema
import config

class ChromaManager:
    def __init__(self):
        self.client = chromadb.PersistentClient(
            path=config.CHROMA_DB_PATH,
            settings=Settings(allow_reset=True)
        )
        self.collection = self.client.get_or_create_collection(
            name="output_schemas",
            metadata={"description": "Storage for output JSON schemas and their descriptions"}
        )
    
    def store_output_schema(self, schema: OutputSchema) -> str:
        schema_id = str(uuid.uuid4())
        schema.created_at = datetime.now().isoformat()
        
        documents = [json.dumps(schema.schema_data)]
        metadatas = [{
            "nickname": schema.nickname,
            "field_descriptions": json.dumps(schema.field_descriptions or {}),
            "created_at": schema.created_at,
            "schema_id": schema_id
        }]
        ids = [schema_id]
        
        self.collection.add(
            documents=documents,
            metadatas=metadatas,
            ids=ids
        )
        
        return schema_id
    
    def get_schema_by_nickname(self, nickname: str) -> Optional[OutputSchema]:
        results = self.collection.query(
            query_texts=[nickname],
            n_results=1,
            where={"nickname": nickname}
        )
        
        if not results['documents']:
            return None
        
        metadata = results['metadatas'][0]
        schema_data = json.loads(results['documents'][0])
        field_descriptions = json.loads(metadata.get('field_descriptions', '{}'))
        
        return OutputSchema(
            nickname=metadata['nickname'],
            schema_data=schema_data,
            field_descriptions=field_descriptions,
            created_at=metadata.get('created_at')
        )
    
    def get_all_schema_nicknames(self) -> List[str]:
        results = self.collection.get()
        return [metadata['nickname'] for metadata in results['metadatas']]
    
    def nickname_exists(self, nickname: str) -> bool:
        results = self.collection.query(
            query_texts=[nickname],
            n_results=1,
            where={"nickname": nickname}
        )
        return len(results['documents']) > 0
    
    def delete_schema(self, nickname: str) -> bool:
        results = self.collection.query(
            query_texts=[nickname],
            n_results=1,
            where={"nickname": nickname}
        )
        
        if results['ids']:
            self.collection.delete(ids=results['ids'][0])
            return True
        return False 