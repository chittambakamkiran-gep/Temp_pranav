import pandas as pd
import json
from typing import Dict, List, Union, Any
from models.schemas import FileType, InputData
import io

class FileProcessor:
    @staticmethod
    def process_file(file_content: bytes, file_type: FileType, filename: str) -> InputData:
        if file_type == FileType.JSON:
            return FileProcessor._process_json(file_content)
        elif file_type == FileType.CSV:
            return FileProcessor._process_csv(file_content)
        elif file_type == FileType.EXCEL:
            return FileProcessor._process_excel(file_content, filename)
        elif file_type == FileType.TXT:
            return FileProcessor._process_txt(file_content)
        else:
            raise ValueError(f"Unsupported file type: {file_type}")

    @staticmethod
    def _process_json(file_content: bytes) -> InputData:
        try:
            content = json.loads(file_content.decode('utf-8'))
            schema = FileProcessor._extract_schema_from_json(content)
            return InputData(
                file_type=FileType.JSON,
                content=content,
                schema=schema
            )
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON format: {str(e)}")

    @staticmethod
    def _process_csv(file_content: bytes) -> InputData:
        try:
            df = pd.read_csv(io.BytesIO(file_content))
            content = df.to_dict('records')
            schema = FileProcessor._extract_schema_from_dataframe(df)
            return InputData(
                file_type=FileType.CSV,
                content=content,
                schema=schema
            )
        except Exception as e:
            raise ValueError(f"Error processing CSV: {str(e)}")

    @staticmethod
    def _process_excel(file_content: bytes, filename: str) -> InputData:
        try:
            df = pd.read_excel(io.BytesIO(file_content))
            content = df.to_dict('records')
            schema = FileProcessor._extract_schema_from_dataframe(df)
            return InputData(
                file_type=FileType.EXCEL,
                content=content,
                schema=schema
            )
        except Exception as e:
            raise ValueError(f"Error processing Excel file: {str(e)}")

    @staticmethod
    def _process_txt(file_content: bytes) -> InputData:
        try:
            text_content = file_content.decode('utf-8')
            try:
                parsed_content = json.loads(text_content)
                schema = FileProcessor._extract_schema_from_json(parsed_content)
                return InputData(
                    file_type=FileType.TXT,
                    content=parsed_content,
                    schema=schema
                )
            except json.JSONDecodeError:
                lines = text_content.strip().split('\n')
                if len(lines) == 1:
                    content = {"text": text_content}
                else:
                    content = [{"line": i+1, "text": line} for i, line in enumerate(lines)]
                schema = FileProcessor._extract_schema_from_json(content)
                return InputData(
                    file_type=FileType.TXT,
                    content=content,
                    schema=schema
                )
        except Exception as e:
            raise ValueError(f"Error processing TXT file: {str(e)}")

    @staticmethod
    def _extract_schema_from_json(data: Union[Dict, List]) -> Dict[str, str]:
        schema = {}
        
        if isinstance(data, list) and data:
            sample_item = data[0]
            if isinstance(sample_item, dict):
                for key, value in sample_item.items():
                    schema[key] = FileProcessor._infer_type(value)
        elif isinstance(data, dict):
            for key, value in data.items():
                schema[key] = FileProcessor._infer_type(value)
        
        return schema

    @staticmethod
    def _extract_schema_from_dataframe(df: pd.DataFrame) -> Dict[str, str]:
        schema = {}
        for column in df.columns:
            dtype = str(df[column].dtype)
            if 'int' in dtype:
                schema[column] = 'integer'
            elif 'float' in dtype:
                schema[column] = 'float'
            elif 'bool' in dtype:
                schema[column] = 'boolean'
            elif 'datetime' in dtype:
                schema[column] = 'datetime'
            else:
                schema[column] = 'string'
        return schema

    @staticmethod
    def _infer_type(value: Any) -> str:
        if isinstance(value, bool):
            return 'boolean'
        elif isinstance(value, int):
            return 'integer'
        elif isinstance(value, float):
            return 'float'
        elif isinstance(value, str):
            return 'string'
        elif isinstance(value, list):
            return 'array'
        elif isinstance(value, dict):
            return 'object'
        else:
            return 'unknown' 