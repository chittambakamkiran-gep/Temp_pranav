from langgraph.graph import StateGraph, END
from typing import TypedDict, Dict, List, Optional, Any
from models.schemas import InputData, OutputSchema, MappingResult, UserFeedback, ComputationResult
from agents.llm_client import LLMClient
from database.chroma_manager import ChromaManager
import numpy as np
import pandas as pd
from langsmith import traceable

class WorkflowState(TypedDict):
    input_data: Optional[InputData]
    output_schema: Optional[OutputSchema]
    mapping_result: Optional[MappingResult]
    user_feedback: Optional[str]
    computation_result: Optional[ComputationResult]
    error: Optional[str]
    step: str

class MappingWorkflow:
    def __init__(self, llm_client: LLMClient, chroma_manager: ChromaManager):
        self.llm_client = llm_client
        self.chroma_manager = chroma_manager
        self.workflow = self._build_workflow()

    def _build_workflow(self) -> StateGraph:
        workflow = StateGraph(WorkflowState)
        
        workflow.add_node("validate_input", self.validate_input_node)
        workflow.add_node("generate_mapping", self.generate_mapping_node)
        workflow.add_node("process_feedback", self.process_feedback_node)
        workflow.add_node("execute_computation", self.execute_computation_node)
        workflow.add_node("handle_error", self.handle_error_node)
        
        workflow.set_entry_point("validate_input")
        
        workflow.add_conditional_edges(
            "validate_input",
            self.validate_input_condition,
            {
                "proceed": "generate_mapping",
                "error": "handle_error"
            }
        )
        
        workflow.add_conditional_edges(
            "generate_mapping",
            self.generate_mapping_condition,
            {
                "success": END,
                "feedback": "process_feedback",
                "error": "handle_error"
            }
        )
        
        workflow.add_conditional_edges(
            "process_feedback",
            self.process_feedback_condition,
            {
                "regenerate": "generate_mapping",
                "execute": "execute_computation",
                "error": "handle_error"
            }
        )
        
        workflow.add_edge("execute_computation", END)
        workflow.add_edge("handle_error", END)
        
        return workflow.compile()

    @traceable
    def validate_input_node(self, state: WorkflowState) -> WorkflowState:
        try:
            if not state.get("input_data") or not state.get("output_schema"):
                state["error"] = "Missing input data or output schema"
                state["step"] = "validation_failed"
                return state
            
            input_schema = state["input_data"].schema
            output_schema = state["output_schema"].schema
            
            if not input_schema or not output_schema:
                state["error"] = "Invalid schema structure"
                state["step"] = "validation_failed"
                return state
            
            state["step"] = "validation_passed"
            return state
            
        except Exception as e:
            state["error"] = f"Validation error: {str(e)}"
            state["step"] = "validation_failed"
            return state

    @traceable
    def generate_mapping_node(self, state: WorkflowState) -> WorkflowState:
        try:
            input_schema = state["input_data"].schema
            output_schema_dict = {
                k: {"field_type": v.field_type, "description": v.description}
                for k, v in state["output_schema"].schema.items()
            }
            
            user_feedback = state.get("user_feedback")
            
            mapping_result = self.llm_client.generate_mapping(
                input_schema=input_schema,
                output_schema=output_schema_dict,
                user_feedback=user_feedback
            )
            
            state["mapping_result"] = mapping_result
            state["step"] = "mapping_generated"
            return state
            
        except Exception as e:
            state["error"] = f"Mapping generation error: {str(e)}"
            state["step"] = "mapping_failed"
            return state

    @traceable
    def process_feedback_node(self, state: WorkflowState) -> WorkflowState:
        try:
            feedback = state.get("user_feedback", "").strip()
            
            if not feedback:
                state["step"] = "no_feedback"
                return state
            
            if "execute" in feedback.lower() or "compute" in feedback.lower():
                state["step"] = "ready_for_execution"
            else:
                state["step"] = "feedback_processed"
            
            return state
            
        except Exception as e:
            state["error"] = f"Feedback processing error: {str(e)}"
            state["step"] = "feedback_failed"
            return state

    @traceable
    def execute_computation_node(self, state: WorkflowState) -> WorkflowState:
        try:
            input_data = state["input_data"].content
            mappings = state["mapping_result"].mappings
            
            if isinstance(input_data, list):
                df = pd.DataFrame(input_data)
            else:
                df = pd.DataFrame([input_data])
            
            output_data = {}
            execution_log = []
            
            for mapping in mappings:
                try:
                    formula = mapping.formula
                    
                    local_vars = {}
                    for col in df.columns:
                        local_vars[col] = df[col].values
                    
                    local_vars['np'] = np
                    
                    result = eval(formula, {"__builtins__": {}, "np": np}, local_vars)
                    
                    if hasattr(result, '__iter__') and not isinstance(result, str):
                        if len(result) == 1:
                            output_data[mapping.output_field] = result[0]
                        else:
                            output_data[mapping.output_field] = result.tolist()
                    else:
                        output_data[mapping.output_field] = result
                    
                    execution_log.append(f"Successfully executed: {mapping.output_field} = {formula}")
                    
                except Exception as e:
                    execution_log.append(f"Error executing {mapping.output_field}: {str(e)}")
                    output_data[mapping.output_field] = None
            
            computation_result = ComputationResult(
                output_data=output_data,
                execution_log=execution_log,
                success=len([x for x in output_data.values() if x is not None]) > 0
            )
            
            state["computation_result"] = computation_result
            state["step"] = "computation_completed"
            return state
            
        except Exception as e:
            state["error"] = f"Computation error: {str(e)}"
            state["step"] = "computation_failed"
            return state

    def handle_error_node(self, state: WorkflowState) -> WorkflowState:
        error_msg = state.get("error", "Unknown error occurred")
        state["step"] = "error_handled"
        return state

    def validate_input_condition(self, state: WorkflowState) -> str:
        return "error" if state.get("error") else "proceed"

    def generate_mapping_condition(self, state: WorkflowState) -> str:
        if state.get("error"):
            return "error"
        elif state.get("user_feedback"):
            return "feedback"
        else:
            return "success"

    def process_feedback_condition(self, state: WorkflowState) -> str:
        if state.get("error"):
            return "error"
        elif state.get("step") == "ready_for_execution":
            return "execute"
        else:
            return "regenerate"

    async def run_workflow(self, initial_state: WorkflowState) -> WorkflowState:
        result = await self.workflow.ainvoke(initial_state)
        return result 