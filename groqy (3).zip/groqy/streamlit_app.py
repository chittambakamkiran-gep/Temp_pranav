import streamlit as st
import json
import pandas as pd
from typing import Dict, Any, List, Optional
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from app.models.schemas import OutputSchema, MappingRequest, MappingResponse
from app.database.chroma_manager import ChromaManager
from app.utils.file_processor import FileProcessor
from app.agents.mapping_agent import MappingAgent
from app.compute.executor import DataProcessor
import config

st.set_page_config(
    page_title="GroqY JSON Mapper",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)

def initialize_session_state():
    if 'input_data' not in st.session_state:
        st.session_state.input_data = None
    if 'output_schema' not in st.session_state:
        st.session_state.output_schema = None
    if 'mappings' not in st.session_state:
        st.session_state.mappings = None
    if 'chroma_manager' not in st.session_state:
        st.session_state.chroma_manager = ChromaManager()
    if 'mapping_agent' not in st.session_state:
        st.session_state.mapping_agent = MappingAgent()
    if 'data_processor' not in st.session_state:
        st.session_state.data_processor = DataProcessor()

def render_header():
    st.markdown("""
    <div style="text-align: center; padding: 2rem 0; background: linear-gradient(90deg, #667eea 0%, #764ba2 100%); border-radius: 10px; margin-bottom: 2rem;">
        <h1 style="color: white; margin: 0; font-size: 3rem;">🎯 GroqY JSON Mapper</h1>
        <p style="color: #f0f0f0; margin: 0.5rem 0 0 0; font-size: 1.2rem;">Intelligent AI-Powered JSON Data Transformation</p>
    </div>
    """, unsafe_allow_html=True)

def render_sidebar():
    with st.sidebar:
        st.markdown("### 🔧 Configuration")
        
        if not config.GROQ_API_KEY:
            st.error("⚠️ GROQ API Key not found!")
            st.info("Please set your GROQ_API_KEY in environment variables")
            return False
        else:
            st.success("✅ GROQ API Key configured")
        
        st.markdown("### 📋 Process Steps")
        steps = [
            "Upload Input File",
            "Select/Upload Output Schema", 
            "Generate Mappings",
            "Review & Modify",
            "Execute Transformation"
        ]
        
        for i, step in enumerate(steps, 1):
            st.markdown(f"**{i}.** {step}")
        
        return True

def render_input_section():
    st.markdown("## 📁 Input Data Upload")
    
    uploaded_file = st.file_uploader(
        "Upload your input file (JSON, CSV, Excel, TXT)",
        type=['json', 'csv', 'xlsx', 'xls', 'txt'],
        help="Upload a file containing the data you want to transform"
    )
    
    if uploaded_file is not None:
        try:
            file_content = uploaded_file.read()
            file_name = uploaded_file.name
            file_type = file_name.split('.')[-1].lower()
            
            with st.spinner("Processing input file..."):
                processor = FileProcessor()
                input_data = processor.process_file(file_content, file_name, file_type)
                st.session_state.input_data = input_data
            
            st.success(f"✅ Successfully processed {file_name}")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("### 📊 Sample Data")
                st.json(input_data.data, expanded=False)
            
            with col2:
                st.markdown("### 🏗️ Extracted Schema")
                st.json(input_data.schema, expanded=False)
                
        except Exception as e:
            st.error(f"❌ Error processing file: {str(e)}")

def render_output_schema_section():
    if not st.session_state.input_data:
        st.info("Please upload an input file first")
        return
    
    st.markdown("## 🎯 Output Schema Configuration")
    
    schema_option = st.radio(
        "Choose output schema option:",
        ["Select from existing schemas", "Upload new schema"],
        horizontal=True
    )
    
    if schema_option == "Select from existing schemas":
        nicknames = st.session_state.chroma_manager.get_all_schema_nicknames()
        
        if nicknames:
            selected_nickname = st.selectbox(
                "Select a schema:",
                nicknames,
                help="Choose from previously saved output schemas"
            )
            
            if selected_nickname:
                schema = st.session_state.chroma_manager.get_schema_by_nickname(selected_nickname)
                if schema:
                    st.session_state.output_schema = schema
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        st.markdown("### 📋 Schema Structure")
                        st.json(schema.schema_data, expanded=False)
                    
                    with col2:
                        st.markdown("### 📝 Field Descriptions")
                        if schema.field_descriptions:
                            st.json(schema.field_descriptions, expanded=False)
                        else:
                            st.info("No field descriptions available")
        else:
            st.info("No existing schemas found. Please upload a new schema.")
    
    else:
        uploaded_schema = st.file_uploader(
            "Upload output schema file (JSON)",
            type=['json'],
            key="output_schema_upload",
            help="Upload a JSON file defining your desired output structure"
        )
        
        if uploaded_schema is not None:
            try:
                schema_content = uploaded_schema.read()
                schema_data = json.loads(schema_content.decode('utf-8'))
                
                nickname = st.text_input(
                    "Enter a nickname for this schema:",
                    placeholder="e.g., customer_profile_v1",
                    help="This nickname will be used to identify the schema"
                )
                
                if nickname:
                    if st.session_state.chroma_manager.nickname_exists(nickname):
                        st.error(f"❌ Nickname '{nickname}' already exists. Please choose a different one.")
                    else:
                        st.markdown("### 📝 Add Field Descriptions (Optional)")
                        st.info("Provide descriptions for output fields to help the AI generate better mappings")
                        
                        field_descriptions = {}
                        
                        if isinstance(schema_data, dict) and 'properties' in schema_data:
                            fields = list(schema_data['properties'].keys())
                        else:
                            fields = list(schema_data.keys()) if isinstance(schema_data, dict) else []
                        
                        for field in fields:
                            desc = st.text_input(
                                f"Description for '{field}':",
                                key=f"desc_{field}",
                                placeholder="Optional description to guide mapping logic"
                            )
                            if desc:
                                field_descriptions[field] = desc
                        
                        if st.button("💾 Save Output Schema", type="primary"):
                            output_schema = OutputSchema(
                                nickname=nickname,
                                schema_data=schema_data,
                                field_descriptions=field_descriptions if field_descriptions else None
                            )
                            
                            schema_id = st.session_state.chroma_manager.store_output_schema(output_schema)
                            st.session_state.output_schema = output_schema
                            st.success(f"✅ Schema saved successfully with ID: {schema_id}")
                
                col1, col2 = st.columns(2)
                with col1:
                    st.markdown("### 📋 Schema Preview")
                    st.json(schema_data, expanded=False)
                
            except json.JSONDecodeError:
                st.error("❌ Invalid JSON format in schema file")
            except Exception as e:
                st.error(f"❌ Error processing schema file: {str(e)}")

def render_mapping_section():
    if not st.session_state.input_data or not st.session_state.output_schema:
        st.info("Please complete the input and output schema configuration first")
        return
    
    st.markdown("## 🤖 AI Mapping Generation")
    
    col1, col2 = st.columns([3, 1])
    
    with col1:
        user_modifications = st.text_area(
            "Additional instructions for mapping (Optional):",
            placeholder="e.g., 'Use total_amount as sum of price and tax', 'Convert dates to ISO format'",
            help="Provide specific instructions to guide the AI mapping process"
        )
    
    with col2:
        st.markdown("### 🎛️ Controls")
        generate_btn = st.button("🧠 Generate Mappings", type="primary", use_container_width=True)
        
        if st.session_state.mappings:
            if st.button("🔄 Regenerate", use_container_width=True):
                st.session_state.mappings = None
                st.experimental_rerun()
    
    if generate_btn or (st.session_state.mappings is None and st.button("🧠 Generate Mappings", type="primary")):
        with st.spinner("🤖 AI is analyzing schemas and generating mappings..."):
            try:
                mapping_request = MappingRequest(
                    input_schema=st.session_state.input_data.schema,
                    output_schema=st.session_state.output_schema.schema_data,
                    field_descriptions=st.session_state.output_schema.field_descriptions,
                    user_modifications=user_modifications if user_modifications else None
                )
                
                mappings = st.session_state.mapping_agent.generate_mappings(mapping_request)
                st.session_state.mappings = mappings
                
                st.success("✅ Mappings generated successfully!")
                
            except Exception as e:
                st.error(f"❌ Error generating mappings: {str(e)}")
    
    if st.session_state.mappings:
        st.markdown("### 🗺️ Generated Mappings")
        
        st.info(f"**Strategy:** {st.session_state.mappings.explanation}")
        
        mapping_data = []
        for mapping in st.session_state.mappings.mappings:
            mapping_data.append({
                "Output Field": mapping.output_field,
                "Formula": mapping.formula,
                "Input Fields": ", ".join(mapping.input_fields),
                "Description": mapping.description or "No description"
            })
        
        df = pd.DataFrame(mapping_data)
        st.dataframe(df, use_container_width=True, hide_index=True)
        
        st.markdown("### ✅ Validation Results")
        validation_results = st.session_state.data_processor.validate_mappings(
            st.session_state.mappings.mappings,
            st.session_state.input_data.data
        )
        
        valid_count = sum(1 for result in validation_results.values() if result['valid'])
        total_count = len(validation_results)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Valid Mappings", valid_count)
        with col2:
            st.metric("Total Mappings", total_count)
        with col3:
            st.metric("Success Rate", f"{(valid_count/total_count)*100:.1f}%")
        
        for field, result in validation_results.items():
            if result['valid']:
                st.success(f"✅ {field}: {result['result']}")
            else:
                st.error(f"❌ {field}: {result['error']}")

def render_execution_section():
    if not st.session_state.mappings:
        st.info("Please generate mappings first")
        return
    
    st.markdown("## ⚡ Execute Transformation")
    
    if st.button("🚀 Transform Data", type="primary", use_container_width=True):
        with st.spinner("⚡ Applying transformations..."):
            try:
                result = st.session_state.data_processor.process_data(
                    st.session_state.input_data.data,
                    st.session_state.mappings
                )
                
                st.success("✅ Transformation completed successfully!")
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.markdown("### 📥 Input Data")
                    st.json(st.session_state.input_data.data, expanded=False)
                
                with col2:
                    st.markdown("### 📤 Transformed Output")
                    st.json(result, expanded=False)
                
                st.markdown("### 💾 Download Results")
                col1, col2 = st.columns(2)
                
                with col1:
                    st.download_button(
                        "📄 Download JSON",
                        data=json.dumps(result, indent=2),
                        file_name="transformed_output.json",
                        mime="application/json"
                    )
                
                with col2:
                    df_result = pd.DataFrame([result])
                    csv = df_result.to_csv(index=False)
                    st.download_button(
                        "📊 Download CSV",
                        data=csv,
                        file_name="transformed_output.csv",
                        mime="text/csv"
                    )
                
            except Exception as e:
                st.error(f"❌ Error during transformation: {str(e)}")

def main():
    initialize_session_state()
    render_header()
    
    if not render_sidebar():
        return
    
    tab1, tab2, tab3, tab4 = st.tabs(["📁 Input", "🎯 Output Schema", "🗺️ Mappings", "⚡ Execute"])
    
    with tab1:
        render_input_section()
    
    with tab2:
        render_output_schema_section()
    
    with tab3:
        render_mapping_section()
    
    with tab4:
        render_execution_section()
    
    st.markdown("---")
    st.markdown("### 📊 Session Status")
    
    status_col1, status_col2, status_col3, status_col4 = st.columns(4)
    
    with status_col1:
        status = "✅" if st.session_state.input_data else "❌"
        st.markdown(f"**Input Data:** {status}")
    
    with status_col2:
        status = "✅" if st.session_state.output_schema else "❌"
        st.markdown(f"**Output Schema:** {status}")
    
    with status_col3:
        status = "✅" if st.session_state.mappings else "❌"
        st.markdown(f"**Mappings:** {status}")
    
    with status_col4:
        all_ready = all([
            st.session_state.input_data,
            st.session_state.output_schema,
            st.session_state.mappings
        ])
        status = "✅" if all_ready else "❌"
        st.markdown(f"**Ready to Execute:** {status}")

if __name__ == "__main__":
    main() 