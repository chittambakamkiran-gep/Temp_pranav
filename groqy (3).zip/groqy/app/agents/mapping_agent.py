from langchain_groq import ChatGroq
from langchain.schema import HumanMessage, SystemMessage
from langchain.output_parsers import PydanticOutputParser
from langgraph import Graph, StateGraph, START, END
from typing import Dict, Any, List
import json
import config
from app.models.schemas import MappingResponse, MappingRequest, FieldMapping

class MappingAgent:
    def __init__(self):
        self.llm = ChatGroq(
            groq_api_key=config.GROQ_API_KEY,
            model_name="mixtral-8x7b-32768",
            temperature=0.1
        )
        self.parser = PydanticOutputParser(pydantic_object=MappingResponse)
        
    def create_system_prompt(self) -> str:
        return """You are an expert data mapping specialist. Your task is to create precise NumPy-based formulas to map input JSON fields to output JSON fields.

CRITICAL REQUIREMENTS:
1. ONLY use field names that exist in the input schema
2. Generate VALID NumPy formulas using numpy functions (np.sum, np.mean, np.max, np.min, etc.)
3. For direct mappings, use: output_field -> input_field
4. For calculations, use numpy functions: output_field -> np.sum([input_field1, input_field2])
5. DO NOT create formulas for fields that don't exist in input
6. If no suitable mapping exists, set formula to 'None' and explain in description

Available NumPy functions:
- np.sum() for summation
- np.mean() for average
- np.max() for maximum
- np.min() for minimum
- np.std() for standard deviation
- Basic arithmetic: +, -, *, /
- String operations: str() for conversion

Format your response exactly as specified in the schema."""

    def create_user_prompt(self, request: MappingRequest) -> str:
        prompt = f"""
INPUT SCHEMA:
{json.dumps(request.input_schema, indent=2)}

OUTPUT SCHEMA:
{json.dumps(request.output_schema, indent=2)}
"""
        
        if request.field_descriptions:
            prompt += f"\nFIELD DESCRIPTIONS:\n{json.dumps(request.field_descriptions, indent=2)}"
        
        if request.user_modifications:
            prompt += f"\nUSER MODIFICATIONS:\n{request.user_modifications}"
        
        prompt += """

Create precise mappings for each output field using only the available input fields. Ensure all NumPy formulas are syntactically correct and executable."""
        
        return prompt

    def generate_mappings(self, request: MappingRequest) -> MappingResponse:
        system_prompt = self.create_system_prompt()
        user_prompt = self.create_user_prompt(request)
        
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt + f"\n\n{self.parser.get_format_instructions()}")
        ]
        
        try:
            response = self.llm.invoke(messages)
            parsed_response = self.parser.parse(response.content)
            
            validated_mappings = []
            input_fields = self._extract_input_fields(request.input_schema)
            
            for mapping in parsed_response.mappings:
                if self._validate_mapping(mapping, input_fields):
                    validated_mappings.append(mapping)
                else:
                    validated_mappings.append(FieldMapping(
                        output_field=mapping.output_field,
                        formula="None",
                        input_fields=[],
                        description=f"No valid mapping found for {mapping.output_field}"
                    ))
            
            return MappingResponse(
                mappings=validated_mappings,
                explanation=parsed_response.explanation
            )
            
        except Exception as e:
            fallback_mappings = self._create_fallback_mappings(request)
            return MappingResponse(
                mappings=fallback_mappings,
                explanation=f"Error generating mappings: {str(e)}. Provided fallback mappings."
            )
    
    def _extract_input_fields(self, schema: Dict[str, Any]) -> List[str]:
        fields = []
        if "properties" in schema:
            fields.extend(schema["properties"].keys())
        else:
            fields.extend(schema.keys())
        return fields
    
    def _validate_mapping(self, mapping: FieldMapping, input_fields: List[str]) -> bool:
        if mapping.formula == "None":
            return True
        
        for field in mapping.input_fields:
            if field not in input_fields:
                return False
        return True
    
    def _create_fallback_mappings(self, request: MappingRequest) -> List[FieldMapping]:
        input_fields = self._extract_input_fields(request.input_schema)
        output_fields = self._extract_input_fields(request.output_schema)
        
        mappings = []
        for output_field in output_fields:
            if output_field in input_fields:
                mappings.append(FieldMapping(
                    output_field=output_field,
                    formula=output_field,
                    input_fields=[output_field],
                    description=f"Direct mapping from {output_field}"
                ))
            else:
                mappings.append(FieldMapping(
                    output_field=output_field,
                    formula="None",
                    input_fields=[],
                    description=f"No suitable input field found for {output_field}"
                ))
        
        return mappings

def create_mapping_graph() -> StateGraph:
    def mapping_node(state: Dict[str, Any]) -> Dict[str, Any]:
        agent = MappingAgent()
        request = MappingRequest(**state["request"])
        response = agent.generate_mappings(request)
        
        return {
            "mappings": response.dict(),
            "status": "completed"
        }
    
    graph = StateGraph({
        "request": dict,
        "mappings": dict,
        "status": str
    })
    
    graph.add_node("mapping", mapping_node)
    graph.add_edge(START, "mapping")
    graph.add_edge("mapping", END)
    
    return graph.compile() 