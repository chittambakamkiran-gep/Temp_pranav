import numpy as np
import pandas as pd
from typing import Dict, Any, List
import json
import ast
import operator
from app.models.schemas import FieldMapping, MappingResponse

class FormulaExecutor:
    
    def __init__(self):
        self.safe_operators = {
            ast.Add: operator.add,
            ast.Sub: operator.sub,
            ast.Mult: operator.mul,
            ast.Div: operator.truediv,
            ast.USub: operator.neg,
            ast.UAdd: operator.pos,
        }
        
        self.numpy_functions = {
            'sum': np.sum,
            'mean': np.mean,
            'average': np.mean,
            'max': np.max,
            'min': np.min,
            'std': np.std,
            'var': np.var,
            'median': np.median,
            'round': np.round,
            'abs': np.abs,
            'sqrt': np.sqrt,
            'log': np.log,
            'exp': np.exp
        }
    
    def execute_mappings(self, input_data: Dict[str, Any], mappings: List[FieldMapping]) -> Dict[str, Any]:
        output_data = {}
        
        for mapping in mappings:
            try:
                if mapping.formula == "None" or not mapping.formula:
                    output_data[mapping.output_field] = None
                    continue
                
                result = self._evaluate_formula(mapping.formula, input_data)
                output_data[mapping.output_field] = result
                
            except Exception as e:
                output_data[mapping.output_field] = None
                print(f"Error executing formula for {mapping.output_field}: {str(e)}")
        
        return output_data
    
    def _evaluate_formula(self, formula: str, input_data: Dict[str, Any]) -> Any:
        formula = formula.strip()
        
        if formula in input_data:
            return input_data[formula]
        
        if formula.startswith('np.'):
            return self._evaluate_numpy_formula(formula, input_data)
        
        if self._is_simple_field_reference(formula, input_data):
            return input_data.get(formula)
        
        return self._safe_eval(formula, input_data)
    
    def _evaluate_numpy_formula(self, formula: str, input_data: Dict[str, Any]) -> Any:
        try:
            formula = formula.replace('np.', '')
            
            if formula.startswith('sum('):
                return self._execute_numpy_function('sum', formula, input_data)
            elif formula.startswith('mean('):
                return self._execute_numpy_function('mean', formula, input_data)
            elif formula.startswith('max('):
                return self._execute_numpy_function('max', formula, input_data)
            elif formula.startswith('min('):
                return self._execute_numpy_function('min', formula, input_data)
            elif formula.startswith('std('):
                return self._execute_numpy_function('std', formula, input_data)
            else:
                for func_name in self.numpy_functions:
                    if formula.startswith(f'{func_name}('):
                        return self._execute_numpy_function(func_name, formula, input_data)
            
            return self._safe_eval(f"np.{formula}", input_data)
            
        except Exception as e:
            raise ValueError(f"Error evaluating NumPy formula '{formula}': {str(e)}")
    
    def _execute_numpy_function(self, func_name: str, formula: str, input_data: Dict[str, Any]) -> Any:
        func = self.numpy_functions.get(func_name)
        if not func:
            raise ValueError(f"Unsupported NumPy function: {func_name}")
        
        args_str = formula[len(func_name)+1:-1]
        
        if args_str.startswith('[') and args_str.endswith(']'):
            field_names = [name.strip().strip('"\'') for name in args_str[1:-1].split(',')]
            values = []
            for field_name in field_names:
                if field_name in input_data:
                    val = input_data[field_name]
                    if val is not None:
                        try:
                            values.append(float(val))
                        except (ValueError, TypeError):
                            values.append(0)
            
            if values:
                return func(values)
            else:
                return None
        else:
            field_name = args_str.strip().strip('"\'')
            if field_name in input_data:
                val = input_data[field_name]
                if val is not None:
                    try:
                        if isinstance(val, (list, tuple)):
                            return func([float(x) for x in val if x is not None])
                        else:
                            return func([float(val)])
                    except (ValueError, TypeError):
                        return None
            return None
    
    def _is_simple_field_reference(self, formula: str, input_data: Dict[str, Any]) -> bool:
        return formula in input_data
    
    def _safe_eval(self, expression: str, input_data: Dict[str, Any]) -> Any:
        try:
            allowed_names = dict(input_data)
            allowed_names.update({
                'np': np,
                'sum': sum,
                'max': max,
                'min': min,
                'abs': abs,
                'round': round,
                'float': float,
                'int': int,
                'str': str,
                'len': len
            })
            
            for key, value in input_data.items():
                if isinstance(value, (int, float)):
                    allowed_names[key] = float(value)
                else:
                    allowed_names[key] = value
            
            node = ast.parse(expression, mode='eval')
            return self._eval_node(node.body, allowed_names)
            
        except Exception as e:
            raise ValueError(f"Error evaluating expression '{expression}': {str(e)}")
    
    def _eval_node(self, node, context):
        if isinstance(node, ast.Constant):
            return node.value
        elif isinstance(node, ast.Name):
            if node.id in context:
                return context[node.id]
            else:
                raise NameError(f"Name '{node.id}' is not defined")
        elif isinstance(node, ast.BinOp):
            left = self._eval_node(node.left, context)
            right = self._eval_node(node.right, context)
            op_func = self.safe_operators.get(type(node.op))
            if op_func:
                return op_func(left, right)
            else:
                raise ValueError(f"Unsupported operation: {type(node.op)}")
        elif isinstance(node, ast.UnaryOp):
            operand = self._eval_node(node.operand, context)
            op_func = self.safe_operators.get(type(node.op))
            if op_func:
                return op_func(operand)
            else:
                raise ValueError(f"Unsupported unary operation: {type(node.op)}")
        elif isinstance(node, ast.Call):
            func_name = node.func.id if isinstance(node.func, ast.Name) else str(node.func)
            if func_name in context:
                func = context[func_name]
                args = [self._eval_node(arg, context) for arg in node.args]
                return func(*args)
            else:
                raise NameError(f"Function '{func_name}' is not defined")
        else:
            raise ValueError(f"Unsupported AST node type: {type(node)}")

class DataProcessor:
    
    def __init__(self):
        self.executor = FormulaExecutor()
    
    def process_data(self, input_data: Dict[str, Any], mapping_response: MappingResponse) -> Dict[str, Any]:
        try:
            return self.executor.execute_mappings(input_data, mapping_response.mappings)
        except Exception as e:
            raise ValueError(f"Error processing data with mappings: {str(e)}")
    
    def validate_mappings(self, mappings: List[FieldMapping], input_data: Dict[str, Any]) -> Dict[str, Any]:
        validation_results = {}
        
        for mapping in mappings:
            try:
                if mapping.formula != "None" and mapping.formula:
                    result = self.executor._evaluate_formula(mapping.formula, input_data)
                    validation_results[mapping.output_field] = {
                        "valid": True,
                        "result": result,
                        "error": None
                    }
                else:
                    validation_results[mapping.output_field] = {
                        "valid": False,
                        "result": None,
                        "error": "No formula provided"
                    }
            except Exception as e:
                validation_results[mapping.output_field] = {
                    "valid": False,
                    "result": None,
                    "error": str(e)
                }
        
        return validation_results 