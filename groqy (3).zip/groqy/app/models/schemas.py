from pydantic import BaseModel, Field
from typing import Dict, List, Any, Optional
import json

class FieldMapping(BaseModel):
    output_field: str = Field(description="Name of the output field")
    formula: str = Field(description="NumPy formula for mapping")
    input_fields: List[str] = Field(description="Input fields used in the formula")
    description: Optional[str] = Field(default=None, description="Description of the mapping logic")

class MappingResponse(BaseModel):
    mappings: List[FieldMapping] = Field(description="List of field mappings")
    explanation: str = Field(description="Overall explanation of the mapping strategy")

class OutputSchema(BaseModel):
    nickname: str = Field(description="Unique nickname for the schema")
    schema_data: Dict[str, Any] = Field(description="JSON schema structure")
    field_descriptions: Optional[Dict[str, str]] = Field(default=None, description="Descriptions for each field")
    created_at: Optional[str] = Field(default=None, description="Creation timestamp")

class InputData(BaseModel):
    file_name: str
    file_type: str
    data: Dict[str, Any]
    schema: Dict[str, Any]

class MappingRequest(BaseModel):
    input_schema: Dict[str, Any]
    output_schema: Dict[str, Any]
    field_descriptions: Optional[Dict[str, str]] = None
    user_modifications: Optional[str] = None 