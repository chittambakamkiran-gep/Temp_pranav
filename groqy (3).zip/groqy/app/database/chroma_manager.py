import chromadb
from chromadb.config import Settings
import json
import uuid
from datetime import datetime
from typing import List, Dict, Any, Optional
from app.models.schemas import OutputSchema
import config

class ChromaManager:
    def __init__(self):
        self.client = chromadb.PersistentClient(
            path=config.CHROMA_DB_PATH,
            settings=Settings(allow_reset=True)
        )
        self.collection = self.client.get_or_create_collection(
            name="output_schemas",
            metadata={"description": "Storage for output JSON schemas and their descriptions"}
        )
    
    def store_output_schema(self, schema: OutputSchema) -> str:
        schema_id = str(uuid.uuid4())
        schema.created_at = datetime.now().isoformat()
        
        documents = [json.dumps(schema.schema_data)]
        metadatas = [{
            "nickname": schema.nickname,
            "field_descriptions": json.dumps(schema.field_descriptions or {}),
            "created_at": schema.created_at,
            "schema_id": schema_id
        }]
        ids = [schema_id]
        
        self.collection.add(
            documents=documents,
            metadatas=metadatas,
            ids=ids
        )
        
        return schema_id
    
    def get_schema_by_nickname(self, nickname: str) -> Optional[OutputSchema]:
        try:
            results = self.collection.get(
                where={"nickname": nickname},
                limit=1
            )
            
            if not results['documents'] or len(results['documents']) == 0:
                return None
            
            document = results['documents'][0]
            metadata = results['metadatas'][0]
            
            schema_data = json.loads(document)
            
            field_descriptions_str = metadata.get('field_descriptions', '{}')
            if isinstance(field_descriptions_str, dict):
                field_descriptions = field_descriptions_str
            elif isinstance(field_descriptions_str, str):
                try:
                    field_descriptions = json.loads(field_descriptions_str)
                except json.JSONDecodeError:
                    field_descriptions = {}
            else:
                field_descriptions = {}
            
            return OutputSchema(
                nickname=metadata['nickname'],
                schema_data=schema_data,
                field_descriptions=field_descriptions,
                created_at=metadata.get('created_at')
            )
            
        except Exception as e:
            print(f"Error retrieving schema by nickname {nickname}: {e}")
            return None
    
    def get_all_schema_nicknames(self) -> List[str]:
        try:
            results = self.collection.get()
            if results['metadatas']:
                return [metadata['nickname'] for metadata in results['metadatas']]
            return []
        except Exception as e:
            print(f"Error getting all schema nicknames: {e}")
            return []
    
    def nickname_exists(self, nickname: str) -> bool:
        try:
            results = self.collection.get(
                where={"nickname": nickname},
                limit=1
            )
            return len(results['documents']) > 0
        except Exception as e:
            print(f"Error checking if nickname exists: {e}")
            return False
    
    def delete_schema(self, nickname: str) -> bool:
        try:
            results = self.collection.get(
                where={"nickname": nickname},
                limit=1
            )
            
            if results['ids'] and len(results['ids']) > 0:
                self.collection.delete(ids=results['ids'])
                return True
            return False
        except Exception as e:
            print(f"Error deleting schema: {e}")
            return False 