# 🎯 GroqY JSON Mapper

An intelligent AI-powered application for transforming JSON data using GROQ LLM, LangGraph agents, and ChromaDB storage.

## ✨ Features

- **Multi-format Input Support**: JSON, CSV, Excel (xlsx/xls), and TXT files
- **AI-Powered Mapping**: GROQ LLM generates NumPy-based transformation formulas
- **Schema Management**: Store and reuse output schemas with ChromaDB
- **Interactive UI**: Beautiful Streamlit interface with drag-and-drop file uploads
- **LangGraph Integration**: Agentic workflow management
- **LangSmith Observability**: Full tracing and monitoring support
- **Safe Execution**: Secure formula evaluation with validation
- **Export Options**: Download results as JSON or CSV

## 🚀 Quick Start

### Prerequisites

- Python 3.8+
- GROQ API Key
- LangSmith API Key (optional, for observability)

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd groqy
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Set up environment variables:
```bash
# Create a .env file in the root directory
GROQ_API_KEY=your_groq_api_key_here
LANGCHAIN_API_KEY=your_langsmith_api_key_here
LANGCHAIN_TRACING_V2=true
LANGCHAIN_PROJECT=groqy-json-mapper
```

### Running the Application

Start the Streamlit application:
```bash
streamlit run streamlit_app.py
```

The application will open in your browser at `http://localhost:8501`

## 📖 Usage Guide

### Step 1: Upload Input Data
- Support formats: JSON, CSV, Excel, TXT
- The system automatically extracts the data schema
- View sample data and schema structure

### Step 2: Configure Output Schema
Choose one of two options:
- **Existing Schema**: Select from previously saved schemas
- **New Schema**: Upload a JSON schema file and optionally add field descriptions

### Step 3: Generate AI Mappings
- The GROQ AI analyzes input and output schemas
- Generates NumPy-based transformation formulas
- Provides validation results and success metrics
- Option to add custom instructions for better mapping

### Step 4: Execute Transformation
- Apply the generated mappings to transform your data
- Download results in JSON or CSV format
- View side-by-side comparison of input and output

## 🏗️ Architecture

```
groqy/
├── app/
│   ├── agents/          # LangGraph agents
│   ├── compute/         # Formula execution engine
│   ├── database/        # ChromaDB management
│   ├── models/          # Pydantic schemas
│   └── utils/           # File processing utilities
├── examples/            # Sample files
├── streamlit_app.py     # Main UI application
├── config.py           # Configuration management
└── requirements.txt    # Dependencies
```

## 🧠 AI Mapping Examples

The AI generates formulas like:
- `profile_id -> customer_id` (direct mapping)
- `full_name -> first_name + " " + last_name` (concatenation)
- `financial_score -> np.mean([account_balance, credit_score])` (calculation)
- `total_spent -> np.sum([last_purchase_amount, account_balance])` (aggregation)

## 🔧 Configuration

### Environment Variables
- `GROQ_API_KEY`: Your GROQ API key (required)
- `LANGCHAIN_API_KEY`: LangSmith API key (optional)
- `LANGCHAIN_TRACING_V2`: Enable tracing (default: true)
- `LANGCHAIN_PROJECT`: Project name for LangSmith

### Supported File Types
- JSON: `.json`
- CSV: `.csv`
- Excel: `.xlsx`, `.xls`
- Text: `.txt`

## 🛡️ Security

- Safe formula evaluation using AST parsing
- Restricted function access
- Input validation and sanitization
- No arbitrary code execution

## 🔍 Troubleshooting

### Common Issues

1. **GROQ API Key Error**
   - Ensure your API key is correctly set in environment variables
   - Check if the key has sufficient credits

2. **File Processing Errors**
   - Verify file format and structure
   - Ensure CSV files have headers
   - JSON files should contain valid JSON

3. **Mapping Generation Issues**
   - Check if input and output schemas are properly formatted
   - Add field descriptions for better AI understanding
   - Try providing custom instructions

## 📊 Example Files

The `examples/` directory contains:
- `sample_input.json`: Example input data
- `sample_input.csv`: CSV format example
- `sample_output_schema.json`: Example output schema

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For support, please create an issue in the GitHub repository or contact the development team. 